#!/usr/bin/env bash
    #to add timestamp in deployment_stack
    NewDate=$(date '+%H%M%N')
    DirName1="deploy"
    DirName2="original"
    cd $DirName1
    cd $DirName2
#Upload the swagger api gateway file
    aws s3 cp APIGATEWAY_LATEST.json s3://sololiveudeployment-qasolo/
    echo Swagger uploaded!
    cd ..
    cd ..
#to rename function name in index.js
for D in functions/*; do
    if [ -d "${D}" ]; then
    cd "${D}"
    echo "${D}"
    sed -i "s|FunctionName: 'tokenverify'|FunctionName: 'tokenverify_qa'|g" index.js
    sed -i "s|FunctionName: 'storetoken'|FunctionName: 'storetoken_qa'|g" index.js
    cd ..
    cd ..
    fi
done
#installs npm modules for Lambda layers
for D in layers/* layers/*/*; do
    if [ -d "${D}" ]; then
     if [ "${D#*/}" == "nodemodules" ]; then
        cd $PWD/layers/nodemodules/nodejs/
        npm install
        echo "Installed node modules"
        cd ..
        cd ..
        cd ..
      fi
    fi
done
#uploads layer zips to AWS s3
for D in layers/*; do
    if [ -d "${D}" ]; then
        cd "${D}"
        zip -r "${D##*/}.zip" ./*
        cd ..
        cd ..
        aws s3 cp $PWD/${D}/${D##*/}.zip s3://sololiveudeployment-qasolo/
    fi
done
#uploads function zips to AWS s3
for D in functions/*; do
    if [ -d "${D}" ]; then
        cd "${D}"
        zip -r "${D##*/}.zip" ./*
        cd ..
        cd ..
        aws s3 cp $PWD/${D}/${D##*/}.zip s3://sololiveudeployment-qasolo/
    fi
done
