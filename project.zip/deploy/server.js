const aws = require('aws-sdk');
const replace = require('replace-in-file');
const fs = require('fs');
const fs_extra = require('fs-extra');
// var shell = require('shelljs');
var express = require('express');
var app = express();
var options;
var port = 3000;

app.get('/task/qasolo', function(req, res) {
    console.log("Inside function call");
    let s3 = new aws.S3({
        region: 'us-east-1'
    });

    var params = {
        Bucket: "sololiveudeployment-qasolo"
        // Delimiter:"*.zip"    
        //Prefix: ".zip"
        //MaxKeys: 20//set the number of key that needs to be retrieved

    };
    var valuepairs = [];
    var OrgNames = [];
    var OrgVersions = [];

    var allKeys = [];

    function listAllVersions(marker, marker2, cb) {
        var params = {
            Bucket: "sololiveudeployment-qasolo"
        };
        if (marker) {
            params.VersionIdMarker = marker;
            params.KeyMarker = marker2;
        }
        s3.listObjectVersions(params, function(err, data) {
            allKeys = allKeys.concat(data.Versions);
            if (data.IsTruncated)
                listAllVersions(data.NextVersionIdMarker, data.NextKeyMarker, cb);
            else
                cb();
        });
    }

    listAllVersions("", "", function() {

        allKeys.forEach(function(element, i) {
            var positionofdot = element.Key.indexOf(".");

            var file_type = element.Key.slice((positionofdot + 1), (element.Key.length));


            if (element.IsLatest) {

                if (file_type === "zip" || file_type === "json") {
                    valuepairs.push({
                        Name: element.Key,
                        Version_ID: element.VersionId
                    });
                    var item_element = element.Key.slice(0, (positionofdot)) + "VerId";
                    OrgNames.push(new RegExp("\\b" + item_element + "\\b"));
                    OrgVersions.push(element.VersionId);

                }
            }
        });
        prepare_files();
        console.log(allKeys);
    });


    prepare_files = function() {
        try {
            fs_extra.emptyDirSync('/home/ubuntu/solocfdeployment-qasolo/deploy' + '/stacks');

            fs_extra.copySync('/home/ubuntu/solocfdeployment-qasolo/deploy' + '/original/deployment_stack01.json', '/home/ubuntu/solocfdeployment-qasolo/deploy' + '/stacks/deployment_stack01.json');
            fs_extra.copySync('/home/ubuntu/solocfdeployment-qasolo/deploy' + '/original/deployment_stack02.json', '/home/ubuntu/solocfdeployment-qasolo/deploy' + '/stacks/deployment_stack02.json');
            console.log('Templates copied!');

            gomaketem1();
        } catch (err) {
            console.log("Error", err);
        }

    };
    gomaketem1 = function () {
        var newDate = Math.floor(Date.now() / 1000);


        options = {

            //Multiple files
            //specify the path of CloudFormation template
            files: ['/home/ubuntu/solocfdeployment-qasolo/deploy' + '/stacks/deployment_stack02.json'],

            from: /ApiGatewayDeployment/g,
            to: "ApiGatewayDeployment" + newDate
        };

        try {
            let changedFiles = replace.sync(options);
            if (changedFiles.length) {
                console.log("Number of modified templates for API Gateway==>" + changedFiles.length + "\n" + 'Modified templates:', changedFiles.join(', '));
                gomaketem();
            } else {

                console.log("No templates were modified!");

            }

        } catch (error) {
            console.error('Error occurred in replacing:', error);
        }
    };
    gomaketem = function () {
        options = {

            //Multiple files
            //specify the path of CloudFormation template with apigateway
            files: ['/home/ubuntu/solocfdeployment-qasolo/deploy' + '/stacks/deployment_stack01.json', '/home/ubuntu/solocfdeployment-qasolo/deploy' + '/stacks/deployment_stack02.json'],

            from: OrgNames,
            to: OrgVersions
        };

        try {
            let changedFiles = replace.sync(options);
            if (changedFiles.length) {
                console.log("Number of modified templates==>" + changedFiles.length + "\n" + 'Modified templates:', changedFiles.join(', '));
                upload_to_s3();
            } else {

                console.log("No templates were modified!");

            }

        } catch (error) {
            console.error('Error occurred in replacing:', error);
        }
    };

    upload_to_s3 = function() {

        Promise.all(options.files.map(function(file, i) {
                return new Promise(function(resolve, reject) {
                    fs.readFile(file, function(err, data) {
                        if (err) {
                            reject("FS read", err);
                        }
                        var base64data = new Buffer(data, 'binary');
                        var uploads3params = {
                            Bucket: "sololiveudeployment-qasolo",
                            Key: "deployment_stack0" + (i + 1) + ".json",
                            Body: base64data
                        };


                        s3.upload(uploads3params, function(err, data) {
                            if (err) {
                                reject("Upload to S3", err);

                            } else {
                                console.log("Template " + data.key + " uploaded!");
                                resolve("Template " + data.key + " uploaded!");

                            }
                        });
                    });
                })
            }))
            .then(function(result) {
                res.send(result);
            })
            .catch(function(err) {
                res.send(err);
            });
    };
});
app.get('/task/app', function(req, res) {
    console.log("Inside function call");
    let s3 = new aws.S3({
        region: 'us-east-1'
    });

    var params = {
        Bucket: "sololiveudeployment-app"
        // Delimiter:"*.zip"
        //Prefix: ".zip"
        //MaxKeys: 20//set the number of key that needs to be retrieved

    };
    var valuepairs = [];
    var OrgNames = [];
    var OrgVersions = [];

    var allKeys = [];

    function listAllVersions(marker, marker2, cb) {
        var params = {
            Bucket: "sololiveudeployment-app"
        };
        if (marker) {
            params.VersionIdMarker = marker;
            params.KeyMarker = marker2;
        }
        s3.listObjectVersions(params, function(err, data) {
            allKeys = allKeys.concat(data.Versions);
            if (data.IsTruncated)
                listAllVersions(data.NextVersionIdMarker, data.NextKeyMarker, cb);
            else
                cb();
        });
    }

    listAllVersions("", "", function() {

        allKeys.forEach(function(element, i) {
            var positionofdot = element.Key.indexOf(".");

            var file_type = element.Key.slice((positionofdot + 1), (element.Key.length));


            if (element.IsLatest) {

                if (file_type === "zip" || file_type === "json") {
                    valuepairs.push({
                        Name: element.Key,
                        Version_ID: element.VersionId
                    });
                    var item_element = element.Key.slice(0, (positionofdot)) + "VerId";
                    OrgNames.push(new RegExp("\\b" + item_element + "\\b"));
                    OrgVersions.push(element.VersionId);

                }
            }
        });
        prepare_files();
        console.log(allKeys);
    });


    prepare_files = function() {
        try {
            fs_extra.emptyDirSync(__dirname + '/stacks');

            fs_extra.copySync(__dirname + '/original/deployment_stack01.json', __dirname + '/stacks/deployment_stack01.json');
            fs_extra.copySync(__dirname + '/original/deployment_stack02.json', __dirname + '/stacks/deployment_stack02.json');
            console.log('Templates copied!');

            gomaketem1();
        } catch (err) {
            console.log("Error", err);
        }

    };
    gomaketem1 = function () {
        var newDate = Math.floor(Date.now() / 1000);


        options = {

            //Multiple files
            //specify the path of CloudFormation template
            files: [__dirname + '/stacks/deployment_stack02.json'],

            from: /ApiGatewayDeployment/g,
            to: "ApiGatewayDeployment" + newDate
        };

        try {
            let changedFiles = replace.sync(options);
            if (changedFiles.length) {
                console.log("Number of modified templates for API Gateway==>" + changedFiles.length + "\n" + 'Modified templates:', changedFiles.join(', '));
                gomaketem();
            } else {

                console.log("No templates were modified!");

            }

        } catch (error) {
            console.error('Error occurred in replacing:', error);
        }
    };
    gomaketem = function() {
        options = {

            //Multiple files
            //specify the path of CloudFormation template
            files: [__dirname + '/stacks/deployment_stack01.json', __dirname + '/stacks/deployment_stack02.json'],

            from: OrgNames,
            to: OrgVersions
        };

        try {
            let changedFiles = replace.sync(options);
            if (changedFiles.length) {
                console.log("Number of modified templates==>" + changedFiles.length + "\n" + 'Modified templates:', changedFiles.join(', '));
                upload_to_s3();
            } else {

                console.log("No templates were modified!");

            }

        } catch (error) {
            console.error('Error occurred in replacing:', error);
        }
    };

    upload_to_s3 = function() {

        Promise.all(options.files.map(function(file, i) {
                return new Promise(function(resolve, reject) {
                    fs.readFile(file, function(err, data) {
                        if (err) {
                            reject("FS read", err);
                        }
                        var base64data = new Buffer(data, 'binary');
                        var uploads3params = {
                            Bucket: "sololiveudeployment-app",
                            Key: "deployment_stack0" + (i + 1) + ".json",
                            Body: base64data
                        };


                        s3.upload(uploads3params, function(err, data) {
                            if (err) {
                                reject("Upload to S3", err);

                            } else {
                                console.log("Template " + data.key + " uploaded!");
                                resolve("Template " + data.key + " uploaded!");

                            }
                        });
                    });
                })
            }))
            .then(function(result) {
                res.send(result);
            })
            .catch(function(err) {
                res.send(err);
            });
    };
});
app.listen(port);
console.log('Server listening on port ' + port);
