//add card details for customer and create subscription
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
var _ = require('lodash');
const stripe = require("stripe")(
    process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const token = await validateToken(params.token);
    const cards = await listCards(params.customer_id);
    const res = await checkCards(cards.data, token);
    const card = res ? undefined : await createCard(params, token.id) ;
    const defaultCard = card ? await updateDefault(params.customer_id, card.id) : {error : "This Card already exists"};
    responseBody.data = {
        response: defaultCard,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };


/**
 * @name validateToken
 * @description verify stripe token
 * */
async function validateToken(token) {
    try {
        const data = await stripe.tokens.retrieve(token);
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name listCards
 * @description get all cards of stripe customer
 * */
async function listCards(customer) {
    try {
        const data = await stripe.customers.listCards(customer);
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name checkCards
 * * @description check if card already exists for customer
 * */
async function checkCards(cardList, token) {
    try {
        var match = _.find(cardList, function(o) {
            return o.fingerprint === token.card.fingerprint;
        });
        return match;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name createCard
 * @description create new source/card
 * */
async function createCard(customer, tokenId) {
    try {
        const data = await stripe.customers.createSource(
            customer.customer_id, {
                source: tokenId,
                metadata: {
                    name: customer.cardholdername
                }
            }
        );
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name updateDefault
 * @description set new added card as primary card
 * */
async function updateDefault(customer, card) {
    try {
        const data = await stripe.customers.update(customer, {
            default_source: card
        });
        console.log(data);
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
