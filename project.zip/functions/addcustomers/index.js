//Add stripe customer
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
const stripe = require("stripe")(
    process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const stripeCus = await createStripeCustomer(params);
    const customer = await addCustomer(stripeCus);
    responseBody.data = {
        response: stripeCus,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };


/**
 * @name createStripeCustomer
 * @description get destination details
 * */
async function createStripeCustomer(user) {
    try {
        const data = await stripe.customers.create({
            email: user.email,
            source: user.token,
            metadata: {
                city: user.city,
                country: user.country,
                add_line1: user.add_line1,
                add_line2: user.add_line2,
                zipcode: user.zipcode,
                state: user.state
            }
        });
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name addCustomer
 * @description get destination details
 * */
async function addCustomer(customer) {
    try {
        const params = {
            Item: {
                customer_id: customer.id,
                email: customer.email
            },
            TableName: 'stripe_users_' + process.env.ENVIRONMENT
        };
        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}