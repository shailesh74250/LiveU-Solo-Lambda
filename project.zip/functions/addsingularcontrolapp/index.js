//Add control app
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const body = JSON.parse(event.body);
    //const body = event.body;
    const app = await addControlapp(body);
    responseBody.data = {
        response: app,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name addControlapp
 * @description add singular control app
 * */
async function addControlapp(event) {
    try {
        const params = {
            Item: {
                id: event.id,
                template_id: event.template_id,
                email: event.email,
                token: event.token,
                thumbnail: event.thumbnail,
                template_name: event.template_name,
                name: event.name,
                license_type: event.license_type
            },
            TableName: 'singular_control_app_' + process.env.ENVIRONMENT
        };
        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
