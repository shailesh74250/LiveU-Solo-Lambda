//Add device usage
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    const body = JSON.parse(event.body);
    const customer = await addDeviceUsage(body);
    responseBody.data = {
        response: customer,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };
});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name addDeviceUsage
 * @description add singular device usage
 * */
async function addDeviceUsage(event) {
    try {
        const params = {
            Item: {
                id: event.id,
                email: event.email,
                provider: event.provider,
                stream_title: event.stream_title,
                unitname: event.unitname,
                devicestatus: event.devicestatus,
                unit_id: event.unit_id
            },
            TableName: 'singular_device_usage_' + process.env.ENVIRONMENT
        };
        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}