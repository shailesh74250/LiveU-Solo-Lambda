//get app subscription details
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
    const subscription = await getSubscription(query.customer_id);
    responseBody.data = {
        response: subscription,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getSubscription
 * @description get app subscription
 * */
async function getSubscription(customer_id) {
    try {
        const params = {
            TableName: "user_subscription_" + process.env.ENVIRONMENT,
            IndexName: "customer_id-index",
            KeyConditionExpression: "#customer_id = :customer_id",
            FilterExpression: "#is_cancel = :is_cancel and attribute_exists(is_type)",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id",
                "#is_cancel": "is_cancel"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id,
                ":is_cancel": false
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items[0];
        }
        else {
            return {};
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
