'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
  region: 'us-east-1'
});

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
  let responseBody = {};
  let statusCode;
  const params = JSON.parse(event.body);
  //const params = event.body;
  const user1 = await scanUser(params);
  if (user1) {
    const sub = await updateUser(params, user1);
  }
  const user = user1 ? await scanUser(params) : user1;
  responseBody.data = {
    response: user,
    requestId: context.awsRequestId
  };
  statusCode = HttpStatus.OK;
  return {
    statusCode: statusCode,
    body: JSON.stringify(responseBody),
    isBase64Encoded: false
  };
});

handler
  .use(httpSecurityHeaders())
  .use(cors({
    origins: ['*']
  }))
  .use(auth());

module.exports = { handler };

/**
 * scanUser
 * @param {object}
 */
async function scanUser(event) {
  try {
    const params = {
      TableName: "app_user_" + process.env.ENVIRONMENT,
      IndexName: "email-index",
      KeyConditionExpression: "#email = :email",
      FilterExpression: "#boss_id = :boss_id",
      ExpressionAttributeNames: {
        "#email": "email",
        "#boss_id": "boss_id"
      },
      ExpressionAttributeValues: {
        ":email": event.email,
        ":boss_id": event.boss_id
      }
    };
    const data = await docClient.query(params).promise();
    if (data.Count) {
      return data.Items[0];
    }
    else {
      return null;
    }
  }
  catch (err) {
    console.log(err);
    throw err;
  }
}

/**
 * updateUser
 * @param {string} customer_id 
 */
async function updateUser(event, user) {
  try {
    const params = {
      TableName: "app_user_" + process.env.ENVIRONMENT,
      Key: {
        "unique_id": user.unique_id
      },
      UpdateExpression: "set isRegistered = :r , lastUpdated = :u",
      ExpressionAttributeValues: {
        ":r": event.is_registered,
        ":u": Math.floor(Date.now() / 1000)
      },
      ReturnValues: "UPDATED_NEW"
    };

    const data = await docClient.update(params).promise();
    return data;
  }
  catch (err) {
    console.log(err);
    throw err;
  }
}
