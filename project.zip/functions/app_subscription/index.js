'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
var { google } = require('googleapis');
var privatekey = require("./privatekey.json");
//var token = "delaikcjmhebgefnadnpochg.AO-J1OwteqkKwCCOcKEJ8jCA89N3lZPdvYvViP62sNFYJdBRpBRVigqA3eQzTBwaCv3y7PTmcASJ0_vz3rtYTiKZRLGo1rdqdHR2PI2Gu52HwECPK6y-2FQJOUaWhmurshZY3ZdnsX5k";
var app_package = "com.live.lusolo";
//var subscription_id = "lrt_monthly_subscription";
var publisher = google.androidpublisher('v2');


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    if (params.type == "android") {
        const jwt = new google.auth.JWT(
            privatekey.client_email,
            null,
            privatekey.private_key, ['https://www.googleapis.com/auth/androidpublisher']
        );
        const googleAuth = await googleLogin(jwt);
        const purchase = await purchasePublish(params);
        params.start_date = await parseInt(purchase.data.startTimeMillis);
        params.end_date = await parseInt(purchase.data.expiryTimeMillis);
    }
    const subscription = await addsubscription(params);
    responseBody.data = {
        response: subscription,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * addsubscription
 * @param {string} customer_id 
 */
async function addsubscription(event) {
    try {
        const params = {
            Item: {
                subscription_id: event.subscription_id,
                plan_id: event.plan_id,
                customer_id: event.customer_id,
                coupon: event.coupon,
                unit_id: event.unit_id,
                service_type: event.service_type,
                is_cancel: false,
                interval: event.interval,
                receipt: event.receipt,
                amount: Math.round(event.amount * 100) / 100,
                start_date: event.start_date,
                end_date: event.end_date,
                type: event.type,
                is_type: event.type // android, app, web
            },
            TableName: 'user_subscription_' + process.env.ENVIRONMENT
        };
        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name googleLogin
 * @description set subscription to cancel 
 * */
async function googleLogin(jwt) {
    try {
        const g_auth = await google.options({ auth: jwt });
        const data = await jwt.authorize();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name purchasePublish
 * @description set subscription to cancel 
 * */
async function purchasePublish(event) {
    try {
        const data = await publisher.purchases.subscriptions.get({
            //auth: jwt,
            packageName: app_package,
            subscriptionId: event.plan_id,
            token: event.receipt
        });
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
