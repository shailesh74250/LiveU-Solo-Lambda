'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
  region: 'us-east-1'
});
var md5 = require('md5');


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
  let responseBody = {};
  let statusCode;
  const params = JSON.parse(event.body);
  //const params = event.body;
  const user1 = await scanUser(params);
  if (user1 == null) {
    const sub = await addUser(params);
  }
  const user = user1 ? user1 : await scanUser(params);
  responseBody.data = {
    response: user,
    requestId: context.awsRequestId
  };
  statusCode = HttpStatus.OK;
  return {
    statusCode: statusCode,
    body: JSON.stringify(responseBody),
    isBase64Encoded: false
  };
});

handler
  .use(httpSecurityHeaders())
  .use(cors({
    origins: ['*']
  }))
  .use(auth());

module.exports = { handler };

/**
 * scanUser
 * @param {string} customer_id 
 */
async function scanUser(event) {
  try {
    var params = {
      TableName: "app_user_" + process.env.ENVIRONMENT,
      IndexName: "email-index",
      KeyConditionExpression: "#email = :email",
      FilterExpression: "#device_id = :device_id",
      ExpressionAttributeNames: {
        "#email": "email",
        "#device_id": "device_id"
      },
      ExpressionAttributeValues: {
        ":email": event.email,
        ":device_id": event.device_id
      }
    };

    const data = await docClient.query(params).promise();
    if (data.Count) {
      return data.Items[0];
    }
    else {
      return null;
    }
  }
  catch (err) {
    console.log(err);
    throw err;
  }
}

/**
 * addUser
 * @param {string} customer_id 
 */
async function addUser(event) {
  try {
    var stringvalue = event.email + event.device_id;
    var unique_id = md5(stringvalue);
    var boss_id = "Boss100_solo_" + unique_id;
    var serial_no = "sa-" + unique_id.substring(0, 5) + "-" + unique_id.substring(7, 13);
    const params = {
      TableName: "app_user_" + process.env.ENVIRONMENT,
      Item: {
        'unique_id': unique_id,
        'boss_id': boss_id,
        'serial_no': serial_no,
        'email': event.email,
        'device_id': event.device_id,
        'isRegistered': 'false',
        'type': event.type,
        'lastUpdated': Math.floor(Date.now() / 1000),
        'created': Math.floor(Date.now() / 1000)
      }
    };

    const data = await docClient.put(params).promise();
    return data;
  }
  catch (err) {
    console.log(err);
    throw err;
  }
}
