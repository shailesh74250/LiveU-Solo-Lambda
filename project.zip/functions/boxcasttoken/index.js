//Boxcast token
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors} = require("solo-utils");
const config = require('./config.json');
const rp = require('request-promise');
var clientId;
var clientSecret;

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;
	const params = JSON.parse(event.body);

		const token = await getToken(params);
		responseBody.data = {
			response: token,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = {handler};

/**
 * @name getToken
 * @description get Mixer token
 * */
async function getToken(event) {
	try {
		switch (process.env.ENVIRONMENT.toUpperCase()) {
			case 'DEV':
				clientId = config.Boxcast.credentials.DEV.clientId;
				clientSecret = config.Boxcast.credentials.DEV.clientSecret;
				break;

			case 'QA':
				clientId = config.Boxcast.credentials.QA.clientId;
				clientSecret = config.Boxcast.credentials.QA.clientSecret;
				break;

			case 'PROD':
				clientId = config.Boxcast.credentials.PROD.clientId;
				clientSecret = config.Boxcast.credentials.PROD.clientSecret;
				break;
			case 'SEMIPROD':
				clientId = config.Boxcast.credentials.SEMIPROD.clientId;
				clientSecret = config.Boxcast.credentials.SEMIPROD.clientSecret;
				break;

			default:
				clientId = config.Boxcast.credentials.DEV.clientId;
				clientSecret = config.Boxcast.credentials.DEV.clientSecret;
				break;
		}
		var	data = {};
		if(event.grant_type === 'authorization_code'){
		data = {
				"code": event.code,
				"redirect_uri": event.redirect_uri,
				"grant_type": event.grant_type
			};
		}
		else
		{
		data =	{
				"refresh_token": event.refresh_token,
				"grant_type": event.grant_type
			};
		}
		var options = {
			method: 'POST',
			uri: config.Boxcast.URI + config.Boxcast.endpoints.token,
			headers: {
			Authorization: 'Basic '+Buffer.from(clientId+':'+clientSecret).toString('base64')
			},
			resolveWithFullResponse: true,
			form: data,
			json: true
		};

		let result = await rp(options);
		return result.body;
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: err.error.error_code,
            property:"boxcast",
            message:err.error.error_description,
        });
	}
}