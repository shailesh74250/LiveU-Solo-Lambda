//Add extra hours in user account
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const customer = await getCustomerLicense(params.customer_id);
    const extrahours = await userExtraHoursHistory(params);
    const license = await updateUserLicense(params, customer);
    responseBody.data = {
        response: license,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getCustomerLicense
 * @description get user stripe customer id 
 * */
async function getCustomerLicense(customer_id) {
    try {
        const params = {
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
            KeyConditionExpression: "#customer_id = :customer_id",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items[0];
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name userExtraHoursHistory
 * @description get destination details
 * */
async function userExtraHoursHistory(event) {
    try {
        const params = {
            Item: {
                id: GetRandomGUID(),
                extra_hours: event.extratime,
                added_on: Math.floor(Date.now() / 1000),
                customer_id: event.customer_id,
                charge_id: event.charge_id,
                license_type: event.license_type
            },
            TableName: 'user_extra_hours_' + process.env.ENVIRONMENT
        };

        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name updateUserLicense
 * @description get destination details
 * */
async function updateUserLicense(event, customer) {
    try {
        const params = {
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
            Key: {
                "customer_id": event.customer_id
            },
            UpdateExpression: "set extra_hours = :h",
            ExpressionAttributeValues: {
                ":h": parseInt(event.extratime) + parseInt(customer.extra_hours)
            },
            ReturnValues: "ALL_NEW"
        };
        const data = await docClient.update(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

function GetRandomGUID() {
    var result;
    var i;
    var j;
    result = '';
    for (j = 0; j < 32; j++) {
        if (j == 8 || j == 12 || j == 16 || j == 20) {
            result = result + '-';
        }
        i = Math.floor(Math.random() * 16).toString(16).toUpperCase();
        result = result + i;
    }
    return result;
}
