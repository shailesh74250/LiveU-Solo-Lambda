//calculate tax
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors, config} = require("solo-utils");
const AWS = require('aws-sdk');
const Taxjar = require('taxjar');
const client = new Taxjar({
    apiKey: process.env.taxjar
});
/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    let params = event.queryStringParameters;
    try {
        const funRes = await getTax(params);
        responseBody.data = {
            response: funRes,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    } catch (err) {
        if (err.statusCode == 401)
            err.statusCode = 403;
        statusCode = err.statusCode;
        err.requestId = context.awsRequestId;
        responseBody.errors = [err];
    }
    return {
        isBase64Encoded: false,
        statusCode: statusCode,
        body: JSON.stringify(responseBody), //JSON.stringify(event)
    };

});
handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = {handler};

//function to get taxrate based on zipcode
async function getTax(params) {
    try {
        const data = await client.ratesForLocation(params.zip, {country: 'US'});
        return data;
    } catch (err) {
        throw new errors.APIError(HttpStatus.INTERNAL_SERVER_ERROR, {
            code: null,
            message: err.message,
        });
    }

}
