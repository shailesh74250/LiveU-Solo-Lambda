//Cancel subscription
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const updatedSubscription = await cancelSubscription(params);
    const subscription = await deleteSubscription(params);
    responseBody.data = {
        response: updatedSubscription,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };


/**
 * @name cancelSubscription
 * @description set subscription to cancel 
 * */
async function cancelSubscription(event) {
    try {
        const data = await stripe.subscriptions.del(
            event.subscription_id, {
                at_period_end: event.periodends
            });
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name deleteSubscription
 * @description get destination details
 * */
async function deleteSubscription(event) {
    try {
        const params = {
            TableName: 'user_subscription_' + process.env.ENVIRONMENT,
            Key: {
                "subscription_id": event.subscription_id
            },
            UpdateExpression: "set is_cancel = :c",
            ExpressionAttributeValues: {
                ":c": true
            },
            ReturnValues: "UPDATED_NEW"
        };
        const data = await docClient.update(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
