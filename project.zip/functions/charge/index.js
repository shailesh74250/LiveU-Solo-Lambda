'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
	process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;
	const params = JSON.parse(event.body);
	//const params = event.body;
	const charges = await createCharge(params);
	responseBody.data = {
		response: charges,
		requestId: context.awsRequestId
	};
	statusCode = HttpStatus.OK;
	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = { handler };


/**
 * @name getCharges
 * @description get all charges of user
 * */
async function createCharge(event) {
	try {
		const data = await stripe.charges.create({
			amount: event.amount,
			currency: "usd",
			capture: true,
			customer: event.customer_id,
			metadata: {
				license_type: event.license_type,
				interval: event.interval,
				tax_rate: event.tax_rate,
				tax_amount: event.tax_amount,
			}
		});
		return data;
	}
	catch (err) {
		throw err;
	}
}
