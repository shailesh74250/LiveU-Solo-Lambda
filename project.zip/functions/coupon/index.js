// function to create,edit,delete stripe coupons
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors, config} = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    let funcRes;
    try {
        if (event.httpMethod === 'GET') {
            if (event.queryStringParameters && event.queryStringParameters.id !== undefined) {
                funcRes = await fetchCoupon(event);
            } else {
                funcRes = await fetchCoupons();
            }
        }
        if (event.httpMethod === 'POST') {
            let params = JSON.parse(event.body);
            funcRes = await createCoupon(params);
        }
        if (event.httpMethod === 'PUT') {
            let params = JSON.parse(event.body);
            funcRes = await updateCoupon(params);
        }
        if (event.httpMethod === 'DELETE') {
            let params = JSON.parse(event.body);
            funcRes = await deleteCoupon(params);
        }
        responseBody.data = {
            response: funcRes,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    } catch (err) {
        if (err.statusCode == 401)
            err.statusCode = 403;
        statusCode = err.statusCode;
        err.requestId = context.awsRequestId;
        responseBody.errors = [err];
    }

    return {
        isBase64Encoded: false,
        statusCode: statusCode,
        body: JSON.stringify(responseBody), //JSON.stringify(event)
    };

});
handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = {handler};

// function to get stripe coupons
async function fetchCoupons() {
    try {
        const data = await stripe.coupons.list({limit: 100});
        return data;
    } catch (err) {
        throw err;
    }
}
// function to get single stripe coupon
async function fetchCoupon(event) {
    try {
        const data = await stripe.coupons.retrieve(event.queryStringParameters.id);
        return data;
    } catch (err) {
        throw err;
    }

}
// function to create stripe coupon
async function createCoupon(params) {
    try {
        const data = await stripe.coupons.create({
            percent_off: params.percent_off,
            amount_off: params.amount_off,
            currency: params.currency,
            duration: params.duration,
            duration_in_months: params.duration_in_months,
            metadata: params.metadata,
            id: params.id,
            max_redemptions: params.max_redemptions,
            redeem_by: params.redeem_by
        });
        return data;
    } catch (err) {
        throw err;
    }
}
// function to update stripe coupon
async function updateCoupon(params) {
    try {
        const data = await stripe.coupons.update(params.id, {metadata: {user: params.user}});
        return data;
    } catch (err) {
        throw err;
    }

}
// function to delete stripe coupon
async function deleteCoupon(params) {
    try {
        const data = await stripe.coupons.del(params.id);
        return data;
    } catch (err) {
        throw err;
    }

}
