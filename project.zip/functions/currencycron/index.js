//Get and store currency
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const AWS = require('aws-sdk');
const config = require('./config.json');
const _ = require('lodash');
var rp = require('request-promise');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
		const currency = await getCurrency();
        responseBody.data = {
            response: currency,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }));
module.exports = { handler };

/**
 * @name getCurrency
 * @description get currency details
 * */
async function getCurrency() {
    try {
    var options = {
	    method: 'GET',
	    url: config.URI,
	    qs: {
	        app_id: config.APPID
	    },
	    headers: {
	        'content-type': 'application/json'
	    },
        json: true
    	};
    	const result = await rp(options);
		_.each(result.rates, function (value, key) {
		var params = 
		{
			Item: {
				"currency": key,
				"amount": value
			},
			TableName: "local_currency"
		};
		docClient.put(params).promise();
	});
	return result.rates;
    }
    catch (err) {
        throw err;
    }
}
