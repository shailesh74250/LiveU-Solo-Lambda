//delete card
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);
const _ = require('lodash');


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const details = await getCustomerDetails(params);
    var match = [];
    if (details.subscriptions.total_count > 0) {
        match = await _.filter(details.subscriptions.data, function(o) {
            return o.cancel_at_period_end === false;
        });
    }
    console.log(match);
    const card = (details.sources.total_count > 1 || (details.sources.total_count == 1 && match.length == 0)) ? await deteleCard(params) : {error : "Card cannot be deleted as you may have an active subscription. Delete all active subscriptions before removing the default card."};
    responseBody.data = {
        response: card,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getCustomerDetails
 * @description get customer details
 * */
async function getCustomerDetails(event) {
    try {
        const data = await stripe.customers.retrieve(event.customer_id);
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name deteleCard
 * @description delete card 
 * */
async function deteleCard(event) {
    try {
        const data = await stripe.customers.deleteCard(
            event.customer_id,
            event.card_id);
        return data;
    }
    catch (err) {
        throw err;
    }
}
