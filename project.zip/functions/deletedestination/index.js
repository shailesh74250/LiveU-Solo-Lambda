//Delete destination
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const param = event.queryStringParameters;
    const destination = await deleteDestination(param.d_id);
    responseBody.data = {
        response: destination,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name deleteDestination
 * @description delete destination
 * */
async function deleteDestination(d_id) {
    try {
        const params = {
            TableName: 'destinations_' + process.env.ENVIRONMENT,
            Key: {
                "d_id": d_id
            },
            ConditionExpression: 'd_id = :d_id',
            ExpressionAttributeValues: {
                ":d_id": d_id
            }
        };
        const data = await docClient.delete(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}