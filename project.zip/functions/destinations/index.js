//Add LUC destination
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
var _ = require('lodash');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
AWS.config.update({ region: 'us-east-1' });
var dynamoose = require('dynamoose');
var dynamoDB = new AWS.DynamoDB();
dynamoose.setDDB(dynamoDB);
const crypto = require('crypto');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const param = JSON.parse(event.body);
    //const param = event.body;
    const unitdest = await getDestinationUnits(param);
    if (unitdest) {
        const removedUnit = await removeUnit(unitdest, param.unit_id);
        const updateDest = await updateDestinations(removedUnit);
    }
    const dest = await getDestination(param.destination_id);
    console.log(dest);
    const setUnit = dest ? await setUnits(dest, param.unit_id) : param.unit_id;
    console.log(setUnit)
    const destination = await addDestination(param, setUnit);
    responseBody.data = {
        response: destination,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * getDestinationUnits
 * @description get destinations of inventory with same unit id 
 */
async function getDestinationUnits(event) {
    try {
        const params = {
            TableName: "destinations_" + process.env.ENVIRONMENT,
            IndexName: "inventory_id-index",
            KeyConditionExpression: "#inventory_id = :inventory_id",
            FilterExpression: "contains(#unit_id, :unit_id)",
            ExpressionAttributeNames: {
                "#unit_id": "unit_id",
                "#inventory_id": "inventory_id"
            },
            ExpressionAttributeValues: {
                ":unit_id": event.unit_id,
                ":inventory_id": event.inventory_id
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * removeUnit
 * @description remove unit id from destinations
 */
async function removeUnit(dest, unit) {
    try {
        let destination = [];
        let array = [];
        for (let i = 0; i < dest.length; i++) {
            array = await dest[i].unit_id.split(',');
            let arr = await _.remove(array, (o) => {
                return o != unit;
            });
            let unitarr = await arr.join(',');
            await destination.push({
                'inventory_id': dest[i].inventory_id,
                'd_id': dest[i].d_id,
                'streaming_provider': dest[i].streaming_provider,
                'title': dest[i].title,
                'type': dest[i].type,
                'username': dest[i].username,
                'password': dest[i].password,
                'primary_url': dest[i].primary_url,
                'secondary_url': dest[i].secondary_url,
                'streaming_profile': dest[i].streaming_profile,
                'stream_name': dest[i].stream_name,
                'min_res_override': dest[i].min_res_override,
                'max_res_override': dest[i].max_res_override,
                'min_fps_override': dest[i].min_fps_override,
                'max_fps_override': dest[i].max_fps_override,
                'min_bitrate_override': dest[i].min_bitrate_override,
                'max_bitrate_override': dest[i].max_bitrate_override,
                'unit_id': unitarr
            })
        }
        return destination;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * updateDestinations
 * @description update destinations with unit id
 */
async function updateDestinations(destinations) {
    try {
        let Schema = dynamoose.Schema;
        let destinationSchema = new Schema({
            d_id: {
                type: String
            },
            inventory_id: {
                type: String
            },
            streaming_provider: {
                type: String
            },
            title: {
                type: String
            },
            type: {
                type: String
            },
            username: {
                type: String,
                default: ""
            },
            password: {
                type: String,
                default: ""
            },
            primary_url: {
                type: String
            },
            secondary_url: {
                type: String,
                default: ""
            },
            streaming_profile: {
                type: String
            },
            stream_name: {
                type: String
            },
            min_res_override: {
                type: String,
                default: ""
            },
            max_res_override: {
                type: String,
                default: ""
            },
            min_fps_override: {
                type: String,
                default: ""
            },
            max_fps_override: {
                type: String,
                default: ""
            },
            min_bitrate_override: {
                type: Number,
                default: ""
            },
            max_bitrate_override: {
                type: Number,
                default: ""
            },
            unit_id: {
                type: String,
                default: ""
            }

        });

        const Destinations = dynamoose.model("destinations_" + process.env.ENVIRONMENT, destinationSchema, {
            update: true,
            create: false
        });

        const data = await Destinations.batchPut(destinations);
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * getDestination
 * @description get destination details
 */
async function getDestination(d_id) {
    try {
        const params = {
            TableName: "destinations_" + process.env.ENVIRONMENT,
            KeyConditionExpression: "#d_id = :d_id",
            ExpressionAttributeNames: {
                "#d_id": "d_id"
            },
            ExpressionAttributeValues: {
                ":d_id": d_id
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * setUnits
 * @description set unit id
 */
async function setUnits(dest, unit) {
    try {
        let unit_array = [];
        let unit2_array = await dest[0].unit_id ? dest[0].unit_id.split(',') : [];
        await unit_array.push(unit);
        let final = await unit_array.concat(unit2_array);
        final = await _.uniq(final);
        let units_array = await final.toString();
        return units_array;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}


/**
 * addDestination
 * @description add destination
 */
async function addDestination(event, units) {
    try {
        const params = {
            TableName: 'destinations_' + process.env.ENVIRONMENT,
            Item: {
                'inventory_id': event.inventory_id,
                'd_id': event.destination_id,
                'streaming_provider': event.provider,
                'title': event.title,
                'type': event.type,
                'username': event.username,
                'password': event.password,
                'primary_url': event.pri_url,
                'secondary_url': event.sec_url,
                'streaming_profile': event.profileSelected,
                'stream_name': event.streamname,
                'min_res_override': event.min_overrideResolution,
                'max_res_override': event.max_overrideResolution,
                'min_fps_override': event.min_overrideFramerate,
                'max_fps_override': event.max_overrideFramerate,
                'min_bitrate_override': event.min_overrideBitrate,
                'max_bitrate_override': event.max_overrideBitrate,
                'unit_id': units
            }
        };
        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
