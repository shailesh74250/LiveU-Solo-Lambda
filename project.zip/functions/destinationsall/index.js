//Add all LUC destination
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
var _ = require('lodash');
AWS.config.update({ region: 'us-east-1' });
var dynamoose = require('dynamoose');
var dynamoDB = new AWS.DynamoDB();
dynamoose.setDDB(dynamoDB);
const crypto = require('crypto');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const param = JSON.parse(event.body);
    const destinationRes = await addDestinations(param.destinations);

    responseBody.data = {
        response: destinationRes,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * addDestinations
 * @description add all destinations
 */
async function addDestinations(destinations) {
    try {
        let Schema = dynamoose.Schema;
        let destinationSchema = new Schema({
            d_id: {
                type: String
            },
            inventory_id: {
                type: String
            },
            streaming_provider: {
                type: String
            },
            title: {
                type: String
            },
            type: {
                type: String
            },
            username: {
                type: String,
                default: ""
            },
            password: {
                type: String,
                default: ""
            },
            primary_url: {
                type: String
            },
            secondary_url: {
                type: String,
                default: ""
            },
            streaming_profile: {
                type: String
            },
            stream_name: {
                type: String
            },
            min_res_override: {
                type: String,
                default: ""
            },
            max_res_override: {
                type: String,
                default: ""
            },
            min_fps_override: {
                type: String,
                default: ""
            },
            max_fps_override: {
                type: String,
                default: ""
            },
            min_bitrate_override: {
                type: Number,
                default: ""
            },
            max_bitrate_override: {
                type: Number,
                default: ""
            }
        });

        const Destinations = dynamoose.model("destinations_" + process.env.ENVIRONMENT, destinationSchema, {
            update: true,
            create: false
        });

        const data = await Destinations.batchPut(destinations);
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

function encrypt(text) {

    var cipher = crypto.createCipher('aes-256-cbc', 'd6F3Efeq');
    var crypted = cipher.update(text, 'utf8', 'hex');
    crypted += cipher.final('hex');
    return crypted;
}