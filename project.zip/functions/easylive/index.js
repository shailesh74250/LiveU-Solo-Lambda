//EasyLive ops to create stream,zoneid
'use strict';

let easyLiveUri;
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const eConfig = require('config.json');
const rp = require('request-promise');
/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;

		const token = await getValues(event);
		responseBody.data = {
			response: token,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	})).
    use(errorFormatter());

module.exports = {handler};

/**
 * @name getValues
 * @description perform EasyLive ops such as createstream,zone_id
 * */
async function getValues(event) {
	switch (event.queryStringParameters.ftype) {
		case 'about_me':
			easyLiveUri = eConfig.GoEasyLive.URI + eConfig.GoEasyLive.endpoints.aboutme + event.queryStringParameters.access_token;
			break;

		case 'zone_id':
			easyLiveUri = eConfig.GoEasyLive.URI + eConfig.GoEasyLive.endpoints.zone_id + event.queryStringParameters.access_token + "&zone_id=" + event.queryStringParameters.zone_id + "&type_id=" + event.queryStringParameters.type_id;
			break;

		case 'create_stream':
			easyLiveUri = eConfig.GoEasyLive.URI + eConfig.GoEasyLive.endpoints.create_stream + event.queryStringParameters.access_token + "&zone_id=" + event.queryStringParameters.zone_id + "&type_id=" + event.queryStringParameters.type_id + "&title=" + event.queryStringParameters.stream_title;
			break;
	}
	try {
		var options = {
			method: 'GET',
			uri: easyLiveUri,
			resolveWithFullResponse: true,
			headers: {'Authorization': event.headers.Authorization},
			json: true
		};

		let result = await rp(options);
		return result.body;
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"easylive",
            message:err.error.error,
        });
	}
}