//EasyLive token
'use strict';
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors} = require("solo-utils");
const AWS = require('aws-sdk');
const config = require('config.json');
const rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    const params = event.queryStringParameters;

        const token = await getToken(params);
        responseBody.data = {
            response: token,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = {handler};

/**
 * @name getToken
 * @description get EasyLive token
 * */
async function getToken(event) {
    try {
        // Token function
        var options = {
            method: 'GET',
            uri: `${config.GoEasyLive.URI + config.GoEasyLive.endpoints.token}?client_id=${config.GoEasyLive.credentials.clientId}&client_secret=${config.GoEasyLive.credentials.clientSecret}&redirect_uri=${event.redirect_uri}&code=${event.code}`,
            resolveWithFullResponse: true,
            json: true
        };
        let result = await rp(options);
        return result.body;
    } catch (err) {
        throw new errors.APIError(err.statusCode, {
            code: null,
            property:"easylive",
            message:err.error.error,
        });
    }
}