'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const updatedCard = await updateCard(params);
    responseBody.data = {
        response: updatedCard,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };


/**
 * @name updateCard
 * @description edit card details
 * */
async function updateCard(event) {
    try {
        const data = await stripe.customers.updateCard(
            event.customer_id,
            event.card_id, {
                name: event.name,
                email: event.email,
                exp_month: event.exp_month,
                exp_year: event.exp_year,
                address_city: event.address_city,
                address_country: event.address_country,
                address_line1: event.address_line1,
                address_line2: event.address_line2,
                address_zip: event.address_zip,
                address_state: event.address_state
            });
        return data;
    }
    catch (err) {
        throw err;
    }
}
