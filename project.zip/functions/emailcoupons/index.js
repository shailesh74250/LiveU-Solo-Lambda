// function to edit email template and send email through AWS SES
'use strict';

const fs = require('fs');
const fs_extra = require('fs-extra');
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors, config} = require("solo-utils");
const AWS = require('aws-sdk');
const lambda = new AWS.Lambda({
    region: 'us-east-1'
});

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    let body = JSON.parse(event.body);
    try {
        const funRes = await edittemplate(body);
        const emailRes = funRes ? await email(body, funRes) : {};
        responseBody.data = {
            response: emailRes,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    } catch (err) {
        if (err.statusCode == 401)
            err.statusCode = 403;
        statusCode = err.statusCode;
        err.requestId = context.awsRequestId;
        responseBody.errors = [err];
    }
    return {
        isBase64Encoded: false,
        statusCode: statusCode,
        body: JSON.stringify(responseBody), //JSON.stringify(event)
    };

});
handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = {handler};
// function to edit email template
async function edittemplate(event) {

    try {
        let data = await fs_extra.copy(__dirname + "/index.html", process.env.HOME + '/index.html');
        try {
            let fileData = fs.readFileSync(process.env.HOME + '/index.html', 'utf8');
            let purSales = `<h3><span style="font-size:16px; font-weight: 400;">Your Purchase Order is: </span><span style="font-size:16px;">` + event.purchaseorder + `</span></h3>
                            <h3><span style="font-size:16px; font-weight: 400;">License keys for order:</span><span style="font-size:16px;"> ` + event.salesorder + `</span></h3>`;
            let sales = `<h3><span style="font-size:16px; font-weight: 400;">License keys for order:</span><span style="font-size:16px;"> ` + event.salesorder + `</span></h3>`;
            ``
            let dynamicPurSales = event.purchaseorder ? purSales : sales;
            var result = fileData.replace(/Replacementtext/g, event.dynamicText).replace(/replacepurchasesales/g, dynamicPurSales)
            return result;
        } catch (err) {
            throw err;
        }

    } catch (err) {
        throw err;
    }
}


// function to send email through AWS SES
async function email(event, res) {
    console.log("reached")
    var params = {
        Destination: {
            BccAddresses: event.emailbcc,
            //CcAddresses: event.body.emailcc,
            ToAddresses: event.emailrecipient
        },
        Message: {
            Body: {
                Html: {
                    Charset: "UTF-8",
                    Data: res
                }
            },
            Subject: {
                Charset: 'UTF-8',
                Data: event.emailsubject,
            }
        },
        Source: "solo.help@liveu.tv"
    };

    try {
        let mailconfig = new AWS.SES({apiVersion: '2010-12-01'});
        let mail = await mailconfig.sendEmail(params).promise();
        return mail;
    } catch (err) {
        throw new errors.APIError(HttpStatus.INTERNAL_SERVER_ERROR, {
            code: null,
            message: err.message,
        });
    }


}