'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
	process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;
	const query = event.queryStringParameters;
	const subscriptions = await getSubscriptions(query);
	responseBody.data = {
		response: subscriptions,
		requestId: context.awsRequestId
	};
	statusCode = HttpStatus.OK;
	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = { handler };

/**
 * @name getSubscriptions
 * @description get all subscriptions of customer
 * */
async function getSubscriptions(event) {
	try {
		const data = await stripe.subscriptions.list({customer : event.customer_id,limit: 100});
		return data;
	}
	catch (err) {
		throw err;
	}
}