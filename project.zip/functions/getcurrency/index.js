//Get currency value
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
        const customer = await getCurrency(query);
        responseBody.data = {
            response: customer,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))

module.exports = { handler };
/**
 * @name getCurrency
 * @description get currency value by code 
 * */
async function getCurrency(event) {
    try {
        const params = 
		{
			TableName: "local_currency",
			Key: {
				"currency": event.currency
			}
		};
        const data = await docClient.get(params).promise();
        return data.Item;
    }
    catch (err) {

    throw err;
    }
}