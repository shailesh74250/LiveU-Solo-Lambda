//Get stripe customer id
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
    const customer = await getCustomerId(query.email);
    responseBody.data = {
        response: customer,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getCustomerId
 * @description get user stripe customer id 
 * */
async function getCustomerId(email) {
    try {
        const params = {
            TableName: "stripe_users_" + process.env.ENVIRONMENT,
            IndexName: "email-index",
            KeyConditionExpression: "#email = :email",
            ExpressionAttributeNames: {
                "#email": "email"
            },
            ExpressionAttributeValues: {
                ":email": email
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return [];
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
