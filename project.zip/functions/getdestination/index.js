//Get destination 
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
    const destination = await getDestination(query.d_id);
    responseBody.data = {
        response: destination,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getDestination
 * @description get destination details
 * */
async function getDestination(dest_id) {
    try {
        const params = {
            TableName: "destinations_" + process.env.ENVIRONMENT,
            KeyConditionExpression: "#d_id = :d_id",
            ExpressionAttributeNames: {
                "#d_id": "d_id"
            },
            ExpressionAttributeValues: {
                ":d_id": dest_id
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return [];
        }
    }
    catch (err) {
        console.log(err);
         throw err;
    }
}
