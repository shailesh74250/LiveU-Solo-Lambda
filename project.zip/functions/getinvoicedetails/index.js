'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
    const invoice = await getInvoice(query);
    responseBody.data = {
        response: invoice,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };


/**
 * @name getInvoice
 * @description get invoice details
 * */
async function getInvoice(event) {
    try {
        const data = await stripe.invoices.retrieve(event.id);
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
