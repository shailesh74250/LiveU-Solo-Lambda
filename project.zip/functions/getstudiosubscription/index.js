'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = event.queryStringParameters;
    const customer = await getCustomerLicense(params.customer_id);
    const subscription = customer ? await getStudioSubscription(params) : {message: "No Studio licence"};
    responseBody.data = {
        response: subscription,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getCustomerLicense
 * @description get user stripe customer id 
 * */
async function getCustomerLicense(customer_id) {
    try {
        const params = {
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
            KeyConditionExpression: "#customer_id = :customer_id",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items[0];
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name getStudioSubscription
 * @description get user stripe customer id 
 * */
async function getStudioSubscription(event) {
    try {
        const params = {
            TableName: 'user_studio_usage_' + process.env.ENVIRONMENT,
            IndexName: "customer_id-index",
            KeyConditionExpression: "#customer_id = :customer_id",
            FilterExpression: "#unit_id= :unit_id and #in_use= :in_use",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id",
                "#unit_id": "unit_id",
                "#in_use": "in_use"
            },
            ExpressionAttributeValues: {
                ":customer_id": event.customer_id,
                ":unit_id": event.unit_id,
                ":in_use": true
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
