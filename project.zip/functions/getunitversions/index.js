//Add unit settings
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
  region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
  let responseBody = {};
  let statusCode;
  const query = event.queryStringParameters;
  const user = await getUnitSettings(query.inventory_id);
  responseBody.data = {
    response: user,
    requestId: context.awsRequestId
  };
  statusCode = HttpStatus.OK;
  return {
    statusCode: statusCode,
    body: JSON.stringify(responseBody),
    isBase64Encoded: false
  };


});

handler
  .use(httpSecurityHeaders())
  .use(cors({
    origins: ['*']
  }))
  .use(auth());

module.exports = { handler };


/**
 * @name getUnitSettings
 * @description get unit settings
 * */
async function getUnitSettings(inventory_id) {
  try {
    const params = {
      TableName: "unitsettings_" + process.env.ENVIRONMENT,
      IndexName: "inventory_id-index",
      KeyConditionExpression: "#inventory_id = :inventory_id",
      ExpressionAttributeNames: {
        "#inventory_id": "inventory_id"
      },
      ExpressionAttributeValues: {
        ":inventory_id": inventory_id
      }
    };
    const data = await docClient.query(params).promise();
    if (data.Count) {
      return data.Items;
    }
    else {
      return null;
    }
  }
  catch (err) {
    console.log(err);
    throw err;
  }
}

function encrypt(text) {
  let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return encrypted.toString('hex');
}

function decrypt(text) {
  let iv = Buffer.from(text.iv, 'hex');
  let encryptedText = Buffer.from(text.encryptedData, 'hex');
  let decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(key), iv);
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}
