//Linkedin assets
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
var linkedinConfig = require('config.json');
var rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
        const token = await getAssets(event);
        responseBody.data = {
            response: token,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    })).
    use(errorFormatter());

module.exports = { handler };

/**
 * @name getAssets
 * @description get assets of linkedin user
 * */
async function getAssets(event) {
    try {
    var options = {};
    console.log(event)
    const query = event.queryStringParameters;
	if (event.httpMethod == 'GET' &&  query.action != undefined) {
		options = {
	        method: 'POST',
	        uri: linkedinConfig.Linkedin.URI + linkedinConfig.Linkedin.endpoints.assetstatus +  query.id + "?action=endLiveEvent",
	        resolveWithFullResponse: true,
	        headers: {'Authorization': event.headers.Authorization,
			'X-Restli-Protocol-Version': '2.0.0'},
	        json: true
	    };
    }
    else if (event.httpMethod == 'GET'  &&  query.action == undefined) {
		options = {
	        method: 'GET',
	        uri: linkedinConfig.Linkedin.URI + linkedinConfig.Linkedin.endpoints.assetstatus +  query.id,
	        resolveWithFullResponse: true,
	        headers: {'Authorization': event.headers.Authorization,
			'X-Restli-Protocol-Version': '2.0.0'},
	        json: true
	    };
    }
    else{
        const body = JSON.parse(event.body);
    	var payload = {
		"registerLiveEventRequest":
		 {"owner":body.id,
		 "recipes":["urn:li:digitalmediaRecipe:feedshare-live-video"],
		 "region":body.region}
		};
	    options = {
	        method: 'POST',
	        uri: linkedinConfig.Linkedin.URI + linkedinConfig.Linkedin.endpoints.ingest,
	        resolveWithFullResponse: true,
	        headers: {'Authorization': event.headers.Authorization,
			'X-Restli-Protocol-Version': '2.0.0'},
			body:payload,
	        json: true
	    };
    }
        let result = await rp(options);
        return result.body;
    }
    catch (err) {
        throw new errors.APIError(err.statusCode, {
            code: null,
            property:"linkedin",
            message:err.error.message,
        });
    }
}