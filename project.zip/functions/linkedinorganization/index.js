//Linkedin organization
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
var linkedinConfig = require('config.json');
var rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
        const token = await getOrganization(event);
        responseBody.data = {
            response: token,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    })).
    use(errorFormatter());

module.exports = { handler };

/**
 * @name getOrganization
 * @description get organization details of linkedin user
 * */
async function getOrganization(event) {
    try {
    var options = {
        method: 'GET',
        uri: linkedinConfig.Linkedin.URI + linkedinConfig.Linkedin.endpoints.organization,
        resolveWithFullResponse: true,
        headers: {'Authorization': event.headers.Authorization,
        'X-Restli-Protocol-Version': '2.0.0'},
        json: true
    };
        let result = await rp(options);
        return result.body;
    }
    catch (err) {
        throw new errors.APIError(err.statusCode, {
            code: null,
            property:"linkedin",
            message:err.error.message,
        });
    }
}