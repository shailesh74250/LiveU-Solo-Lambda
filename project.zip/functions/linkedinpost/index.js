//Linkedin post
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
var linkedinConfig = require('config.json');
var rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    
        const token = await createPost(event);
        responseBody.data = {
            response: token,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    })).
    use(errorFormatter());

module.exports = { handler };

/**
 * @name createPost
 * @description create post on linkedin
 * */
async function createPost(event) {
    console.log(event);
    const body = JSON.parse(event.body);
	var payload = {
		"author": body.id,
		"lifecycleState": "PUBLISHED",
		"specificContent": {
			"com.linkedin.ugc.ShareContent": {
				"media": [
					{
						"media": "urn:li:digitalmediaAsset:"+body.assetId,
						"status": "READY"
					}
				],
				"shareCommentary": {
					"attributes": [],
					"text": body.title
				},
				"shareMediaCategory": "LIVE_VIDEO"
			}
		},
		"visibility": {
			"com.linkedin.ugc.MemberNetworkVisibility": body.privacy
		}
	};
    try {
    var options = {
        method: 'POST',
        uri: linkedinConfig.Linkedin.URI + linkedinConfig.Linkedin.endpoints.post,
        resolveWithFullResponse: true,
        headers: {'Authorization': event.headers.Authorization,
		'X-Restli-Protocol-Version': '2.0.0'},
		body:payload,
        json: true
    };
        let result = await rp(options);
        return result.body;
    }
    catch (err) {
        throw new errors.APIError(err.statusCode, {
            code: null,
            property:"linkedin",
            message:err.error.message,
        });
    }
}