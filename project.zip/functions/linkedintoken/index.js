//Linkedin token
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth,errors } = require("solo-utils");
var linkedinConfig = require('config.json');
var rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);

        const token = await getToken(params);
        responseBody.data = {
            response: token,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getToken
 * @description get linkedin token from code
 * */
async function getToken(event) {
    try {
		var options = {
					method: 'POST',
					uri: linkedinConfig.Linkedin.tokenURI + linkedinConfig.Linkedin.endpoints.token,
					resolveWithFullResponse: true,
					form: {
						code: event.code,
						redirect_uri: event.redirect_uri,
						client_id: linkedinConfig.Linkedin.credentials.clientId,
						client_secret: linkedinConfig.Linkedin.credentials.clientSecret,
						grant_type: event.grant_type
					},
					json: true
				};
        let result = await rp(options);
        return result.body;
    }
    catch (err) {
        throw new errors.APIError(err.statusCode, {
            code: null,
            property:"linkedin",
            message:err.error.message,
        });
    }
}