const AWS = require('aws-sdk');
const lambda = new AWS.Lambda({
    region: 'us-east-1'
});

const { config, errors } = require('solo-utils');
const rp = require('request-promise');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const HttpStatus = require('http-status-codes');

var handler = middy(async (event, context, callback) => {
    let responseBody = {};
    let statusCode = "";

    try {
        const data = await authorize(event);
        responseBody.data = {
            "credentials": data,
            "requestId": context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    } catch (err) {
        statusCode = err.statusCode;
        err.requestId = context.awsRequestId;
        responseBody.errors = [err];
    }

    var response = {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

    return response;
});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }));

module.exports = { handler };

async function authorize(event) {

    try {
        let credentials = getCredentails(event);
  
        if (credentials.isAuthorized) {

            let data = await rp(config.getLoginSettings(process.env.ENVIRONMENT, credentials));
                       
            let authData = await lambda.invoke({
                FunctionName: 'storetoken',
                Qualifier: process.env.ENVIRONMENT,
                InvocationType: 'RequestResponse',
                Payload: '{"username": "' + event.headers["x-user-name"] + '","token": "' + data.body.access_token + '"}'
            }).promise();
            
            let tokenResponse = JSON.parse(authData.Payload);
            
            if (tokenResponse.errors) {
                throw tokenResponse.errors[0];
            } else {
                return data.body;
            }

        } else {
            throw new errors.APIError(HttpStatus.UNAUTHORIZED, {
                code: null,
                message:  HttpStatus.getStatusText(HttpStatus.UNAUTHORIZED),
            });
        }

    }
    catch (err) {
        var errormessage = err.message.substring(6);
        throw new errors.APIError(err.statusCode, {
            code: err.code,
            message: JSON.parse(errormessage)
        });
    }
}

function getCredentails(event) {
    var isAuthorized = true;
    if (!event.headers.Authorization) {
        isAuthorized = false;
    }

    var parts = event.headers.Authorization.split(' ');
    if (parts.length < 2) {
        isAuthorized = false;
    }

    var scheme = parts[0],
        credentials = new Buffer(parts[1], 'base64').toString().split(':');

    if (!/Basic/i.test(scheme)) {
        isAuthorized = false;
    }
    if (credentials.length < 2) {
        isAuthorized = false;
    }


    var username = credentials[0];
    var password = credentials[1];
    if (!username || !password) {
        isAuthorized = false;
    }

    return { username: username, password: password, isAuthorized: isAuthorized };
}