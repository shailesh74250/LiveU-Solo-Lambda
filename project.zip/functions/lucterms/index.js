//Add LUC TOS(terms of service) details
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
  region: 'us-east-1'
});
const crypto = require('crypto');


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
  let responseBody = {};
  let statusCode;
  const params = JSON.parse(event.body);
  //const params = event.body;
  const tos = await addTOS(params);
  responseBody.data = {
    response: tos,
    requestId: context.awsRequestId
  };
  statusCode = HttpStatus.OK;
  return {
    statusCode: statusCode,
    body: JSON.stringify(responseBody),
    isBase64Encoded: false
  };
});

handler
  .use(httpSecurityHeaders())
  .use(cors({
    origins: ['*']
  }));

module.exports = { handler };

/**
 * addTOS
 * @param {string} customer_id 
 */
async function addTOS(event) {
  try {
    const params = {
        TableName: 'lucterms_' + process.env.ENVIRONMENT,
        Item: {
            'email': encrypt(event.email),
            'timestamp': Math.floor(Date.now() / 1000).toString()
        }
    };

    const data = await docClient.put(params).promise();
    return data;
  }
  catch (err) {
    throw err;
  }
}

function encrypt(text) {

 var cipher = crypto.createCipher('aes-256-cbc','d6F3Efeq');
  var crypted = cipher.update(text,'utf8','hex');
  crypted += cipher.final('hex');
  return crypted;
}

// function decrypt(text) {
// var decipher = crypto.createDecipher('aes-256-cbc','d6F3Efeq');
//   var dec = decipher.update(text,'hex','utf8');
//   dec += decipher.final('utf8');
//   return dec;
// }