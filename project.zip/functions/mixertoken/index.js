//Mixer token
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors} = require("solo-utils");
const config = require('./config.json');
const rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;
	const params = JSON.parse(event.body);

	const token = await getToken(params);
		responseBody.data = {
			response: token,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = {handler};

/**
 * @name getToken
 * @description get Mixer token
 * */
async function getToken(event) {
	try {
		var options = {
			method: 'POST',
			uri: config.Mixer.URI + config.Mixer.endpoints.token,
			resolveWithFullResponse: true,
			body: {
				code: event.code,
				redirect_uri: event.redirect_uri,
				client_id: config.Mixer.credentials.clientId,
				grant_type: event.grant_type
			},
			json: true
		};
		let result = await rp(options);
		return result.body;
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: err.error.errorCode,
            property:"mixer",
            message:err.error.errorMessage,
        });
	}
}