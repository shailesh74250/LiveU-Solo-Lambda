//Periscope ops to create stream
'use strict';
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const eConfig = require('config.json');
const rp = require('request-promise');
/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;
		const body = JSON.parse(event.body);//event.body;
		const funRes = await createStream(event, body);
		responseBody.data = {
			response: funRes,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    })).
    use(errorFormatter());

module.exports = { handler };

/**
 * @name createStream
 * @description Make Periscope Broadcast
 * */
async function createStream(event, body) {
	try {
		// Broadcast Create API
		var options = {
			method: 'POST',
			uri: eConfig.Periscope.URI + eConfig.Periscope.endpoints.broadcast.create,
			resolveWithFullResponse: true,
			headers: {
				'Authorization': event.headers.Authorization
			},
			body: {
				region: body.region
			},
			json: true
		};
		let result = await rp(options);
		return result.body;
	}
	catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"periscope",
            message:err.error.error_description,
        });
	}
}