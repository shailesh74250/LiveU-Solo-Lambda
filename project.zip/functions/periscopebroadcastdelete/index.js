//Periscope ops to delete stream
'use strict';
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const eConfig = require('config.json');
const rp = require('request-promise');
/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;

		const body = JSON.parse(event.body);//event.body;
		const funRes = await deleteStream(event, body);
		responseBody.data = {
			response: funRes,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    })).
    use(errorFormatter());

module.exports = { handler };
/**
 * @name deleteStream
 * @description delete Periscope Broadcast
 * */
async function deleteStream(event, body) {
	try {
		// Broadcast Delete API
		var options = {
			method: 'POST',
			uri: eConfig.Periscope.URI + eConfig.Periscope.endpoints.broadcast.delete,
			resolveWithFullResponse: true,
			headers: {
				'Authorization': event.headers.Authorization
			},
			body: {
				broadcast_id: body.broadcast_id
			},
			json: true
		};
		let result = await rp(options);
		result.aData = {"deleted":true};
		return result.aData ;
	}
	catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"periscope",
            message:err.error.error_description,
        });
	}
}