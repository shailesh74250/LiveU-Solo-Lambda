//Periscope ops to create broadcast
'use strict';
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const eConfig = require('config.json');
const rp = require('request-promise');
/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;
		const body = JSON.parse(event.body);//event.body;
		const funRes = await createBroadcast(event, body);
		responseBody.data = {
			response: funRes,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    })).
    use(errorFormatter());

module.exports = { handler };
/**
 * @name createBroadcast
 * @description Create Periscope Broadcast
 * */
async function createBroadcast(event, body) {
	try {
		// Broadcast create API
		var options = {
			method: 'POST',
			uri: eConfig.Periscope.URI + eConfig.Periscope.endpoints.broadcast.publish,
			resolveWithFullResponse: true,
			headers: {
				'Authorization': event.headers.Authorization
			},
			body: {
				broadcast_id: body.broadcast_id,
				title: body.title
			},
			json: true
		};
		let result = await rp(options);
		return result.body ;
	}
	catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"periscope",
            message:err.error.error_description,
        });
	}
}