//Periscope ops to know broadcast status
'use strict';
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const eConfig = require('config.json');
const rp = require('request-promise');
/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;

		const funRes = await broadcastStatus(event);
		responseBody.data = {
			response: funRes,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    })).
    use(errorFormatter());


module.exports = { handler };
/**
 * @name broadcastStatus
 * @description Periscope Broadcast status
 * */
async function broadcastStatus(event) {
	try {
		// Broadcast Status API
		var options = {
			method: 'GET',
			uri: eConfig.Periscope.URI + eConfig.Periscope.endpoints.broadcast.status,
			resolveWithFullResponse: true,
			headers: {
				'Authorization': event.headers.Authorization
			},
			qs: {
				id: event.queryStringParameters.id
			},
			json: true
		};
		let result = await rp(options);
		return result.body ;
	}
	catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"periscope",
            message:err.error.error_description,
        });
	}
}