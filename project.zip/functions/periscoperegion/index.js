//Periscope ops to get region
'use strict';
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const eConfig = require('config.json');
const rp = require('request-promise');
/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;

		const funRes = await getRegion(event);
		responseBody.data = {
			response: funRes,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;
		
	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    })).
    use(errorFormatter());

module.exports = { handler };
/**
 * @name getRegion
 * @description To get Periscope region
 * */
async function getRegion(event) {
	try {
		// Region API
		var options = {
			method: 'GET',
			uri: eConfig.Periscope.URI + eConfig.Periscope.endpoints.region,
			resolveWithFullResponse: true,
			headers: {
				'Authorization': event.headers.Authorization
			},
			json: true
		};
		let result = await rp(options);
		return result.body ;
	}
	catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"periscope",
            message:err.error.error_description,
        });
	}
}