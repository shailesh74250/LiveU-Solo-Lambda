//Periscope ops to get periscope token
'use strict';
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors} = require("solo-utils");
const eConfig = require('config.json');
const rp = require('request-promise');
let clientId;
let clientSecret;
/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;

		const body = JSON.parse(event.body);//event.body;
		const funRes = await getToken(event, body);
		responseBody.data = {
			response: funRes,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = {handler};

/**
 * @name getToken
 * @description Get Periscope token
 * */
async function getToken(event, body) {
	try {
		// Token function
		switch (process.env.ENVIRONMENT.toUpperCase()) {
			case 'LOCAL':
				clientId = eConfig.Periscope.credentials.LOCAL.clientId;
				clientSecret = eConfig.Periscope.credentials.LOCAL.clientSecret;
				break;

			case 'DEV':
				clientId = eConfig.Periscope.credentials.DEV.clientId;
				clientSecret = eConfig.Periscope.credentials.DEV.clientSecret;
				break;
			case 'SEMIPROD':
				clientId = eConfig.Periscope.credentials.SEMIPROD.clientId;
				clientSecret = eConfig.Periscope.credentials.SEMIPROD.clientSecret;
				break;

			case 'QA':
				clientId = eConfig.Periscope.credentials.QA.clientId;
				clientSecret = eConfig.Periscope.credentials.QA.clientSecret;
				break;

			case 'PROD':
				clientId = eConfig.Periscope.credentials.PROD.clientId;
				clientSecret = eConfig.Periscope.credentials.PROD.clientSecret;
				break;

			case 'TEST':
				clientId = eConfig.Periscope.credentials.TEST.clientId;
				clientSecret = eConfig.Periscope.credentials.TEST.clientSecret;
				break;

			default:
				clientId = eConfig.Periscope.credentials.LOCAL.clientId;
				clientSecret = eConfig.Periscope.credentials.LOCAL.clientSecret;
				break;
		}
		var options = {
			method: 'POST',
			uri: eConfig.Periscope.URI + eConfig.Periscope.endpoints.token,
			resolveWithFullResponse: true,
			body: {
				code: body.code,
				redirect_uri: body.redirect_uri,
				client_id: clientId,
				client_secret: clientSecret,
				grant_type: body.slug,
				refresh_token: body.refresh_token
			},
			json: true
		};
		let result = await rp(options);
		return result.body;
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"periscope",
            message:err.error.error_description,
        });
	}
}