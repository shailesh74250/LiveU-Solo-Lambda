//Google api
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
	region: 'us-east-1'
});
var { google } = require('googleapis');
var privatekey = require("./privatekey.json");
//var token = "delaikcjmhebgefnadnpochg.AO-J1OwteqkKwCCOcKEJ8jCA89N3lZPdvYvViP62sNFYJdBRpBRVigqA3eQzTBwaCv3y7PTmcASJ0_vz3rtYTiKZRLGo1rdqdHR2PI2Gu52HwECPK6y-2FQJOUaWhmurshZY3ZdnsX5k";
var app_package = "com.live.lusolo";
//var subscription_id = "lrt_monthly_subscription";
var publisher = google.androidpublisher('v2');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;
	const cancelSubscription = await getCancelledSubscription();
	const jwt = new google.auth.JWT(
		privatekey.client_email,
		null,
		privatekey.private_key, ['https://www.googleapis.com/auth/androidpublisher']
	);
	const googleAuth = await googleLogin(jwt);
	if (cancelSubscription.length) {
		await cancelSubscription.forEach(async function(item) {
			const purchase = await purchasePublish(item);
			const updatedSubscription = await updateSubscription(item, purchase);
		});
	}
	const result = cancelSubscription.length ? { "message": "Subscription updated" } : { "message": "No updates" }
	responseBody.data = {
		response: result,
		requestId: context.awsRequestId
	};
	statusCode = HttpStatus.OK;
	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}));

module.exports = { handler };

/**
 * @name getCancelledSubscription
 * @description get destination details
 * */
async function getCancelledSubscription() {
	try {
		var curdate = new Date();
		const params = {
			TableName: "user_subscription_" + process.env.ENVIRONMENT,
			IndexName: "type-index",
			KeyConditionExpression: "#type = :type",
			FilterExpression: "#is_cancel = :iscancel and #e_date <= :edate",
			ExpressionAttributeNames: {
				"#type": "type",
				"#e_date": "end_date",
				"#is_cancel": "is_cancel"
			},
			ExpressionAttributeValues: {
				":type": "android",
				":edate": curdate.getTime(),
				":iscancel": false
			}
		};
		const data = await docClient.query(params).promise();
		return data.Items;
	}
	catch (err) {
		throw err;
	}
}

/**
 * @name googleLogin
 * @description set subscription to cancel 
 * */
async function googleLogin(jwt) {
	try {
		const g_auth = await google.options({ auth: jwt });
		const data = await jwt.authorize();
		return data;
	}
	catch (err) {
		throw err;
	}
}

/**
 * @name purchasePublish
 * @description set subscription to cancel 
 * */
async function purchasePublish(event) {
	try {
		const data = await publisher.purchases.subscriptions.get({
			//auth: jwt,
			packageName: app_package,
			subscriptionId: event.plan_id,
			token: event.receipt
		});
		return data;
	}
	catch (err) {
		throw err;
	}
}


/**
 * @name updateSubscription
 * @description get destination details
 * */
async function updateSubscription(event, item) {
	try {
		const params = item.data.autoRenewing ? {
			TableName: 'user_subscription_' + process.env.ENVIRONMENT,
			Key: {
				"subscription_id": event.subscription_id
			},
			UpdateExpression: "set end_date = :d",
			ExpressionAttributeValues: {
				":d": item.data.expiryTimeMillis
			},
			ReturnValues: "ALL_NEW"
		} : {
			TableName: 'user_subscription_' + process.env.ENVIRONMENT,
			Key: {
				"subscription_id": event.subscription_id
			},
			UpdateExpression: "set is_cancel = :h",
			ExpressionAttributeValues: {
				":h": true
			},
			ReturnValues: "ALL_NEW"
		};
		const data = await docClient.update(params).promise();
		return data.Items;
	}
	catch (err) {
		throw err;
	}
}
