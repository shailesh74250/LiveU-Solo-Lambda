//Register unit
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const config = require('config.json');
const rp = require('request-promise');
const ua = require('universal-analytics');

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;
	let visitor = ua(config.Salesforce.googleAnalyticsID);

	const object = await registerUnit(event);
		if(object.result != 'success'){
			visitor.event("Salesforce Register endpoint-"+process.env.ENVIRONMENT,object.result,event.body,1, function (err) {
				if(err){
				}
			});
		}
			responseBody.data = {
				response: object,
				requestId: context.awsRequestId
			};	
		statusCode = HttpStatus.OK;	
	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	})).
    use(errorFormatter());

module.exports = {handler};
/**
 * @name registerUnit
 * @description register salesforce unit
 * */
async function registerUnit(event) {
	try {
		let body = JSON.parse(event.body);
		//let body = event.body
		let url = '';
		 if(process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod'){
			 url = config.Salesforce.credentials.DEV.URI + config.Salesforce.endpoints.registerunit;
		 }
		 else{
			 url = config.Salesforce.credentials.PROD.URI + config.Salesforce.endpoints.registerunit;
		 }
		let options = {
			method: 'POST',
			uri: url,
			resolveWithFullResponse: true,
			headers: {
				'Authorization': event.headers.Authorization
			},
			body: {
				"SerialNumber": body.number,
				"service_type": body.service,
				"TypeOfAction": body.action,
				"unit_id":body.unit_id,
				"part_number": body.part_number,
				"hours": body.hours,
				"extraHours": body.extra_hours,
				"email": body.email,
				"customerId": body.customer_id,
				"timestamp": Math.floor(Date.now() / 1000),
				"interval": body.interval,
				"amount": body.amount,
				"currencyCode": body.currency_code,
				"paid": body.paid,
				"address_city": body.address_city,
				"address_country": body.address_country,
				"address_line1": body.address_line1,
				"address_line2": body.address_line2,
				"address_state": body.address_state,
				"address_zip": body.address_zip,
				"DealNumber": body.deal_number,
				"RegistrationKey" : body.registrationkey,
                "PromotionalCodes": body.promocode,		
                "SalesTax": body.tax,		
                "LRTSerialNumber": body.lrtnumber
			},
			json: true
		};
		let result = await rp(options);
		return JSON.parse(result.body);
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"salesforce",
            message:err.error,
        });
	}
}