//Add unit settings
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
var _ = require('lodash');
AWS.config.update({ region: 'us-east-1' });
var dynamoose = require('dynamoose');
var dynamoDB = new AWS.DynamoDB();
dynamoose.setDDB(dynamoDB);
const crypto = require('crypto');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const param = JSON.parse(event.body);
    const destinationRes = await addUnitSettings(param.units);

    responseBody.data = {
        response: destinationRes,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * addUnitSettings
 * @description add all units settings in dynamo
 */
async function addUnitSettings(units) {
    try {
       var Schema = dynamoose.Schema;
        var unitSchema = new Schema({
          unit_id: {
            type: String
          },
          inventory_id: {
            type: String
          },
          destination_id: {
            type: String,
            default: ""
          },
          lowdelay: {
            type: Number,
            default: ""
          },
          lrtchannel: {
            type: String,
            default: ""
          },
          sw_version: {
            type: String
          }
        });

        const Unitsettings = dynamoose.model("unitsettings_" + process.env.ENVIRONMENT, unitSchema, { update: true, create: false });

        const data = await Unitsettings.batchPut(units);
        return data;
    }
    catch (err) {
        throw err;
    }
}

function encrypt(text) {
  let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
  let encrypted = cipher.update(text);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return encrypted.toString('hex');
}