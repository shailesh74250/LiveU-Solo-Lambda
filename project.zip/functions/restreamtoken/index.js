//Restream token
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors} = require("solo-utils");
const config = require('./config.json');
const rp = require('request-promise');
var clientId;
var clientSecret;

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;
	const params = JSON.parse(event.body);

		const token = await getToken(params);
		responseBody.data = {
			response: token,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = {handler};
/**
 * @name getToken
 * @description get Restream token
 * */
async function getToken(event) {
	try {
		switch (process.env.ENVIRONMENT.toUpperCase()) {
			case 'LOCAL':
				clientId = config.Restream.credentials.LOCAL.clientId;
				clientSecret = config.Restream.credentials.LOCAL.clientSecret;
				break;

			case 'DEV':
				clientId = config.Restream.credentials.DEV.clientId;
				clientSecret = config.Restream.credentials.DEV.clientSecret;
				break;

			case 'QA':
				clientId = config.Restream.credentials.QA.clientId;
				clientSecret = config.Restream.credentials.QA.clientSecret;
				break;

			case 'PROD':
				clientId = config.Restream.credentials.PROD.clientId;
				clientSecret = config.Restream.credentials.PROD.clientSecret;
				break;

			case 'TEST':
				clientId = config.Restream.credentials.TEST.clientId;
				clientSecret = config.Restream.credentials.TEST.clientSecret;
				break;
			case 'SEMIPROD':
				clientId = config.Restream.credentials.SEMIPROD.clientId;
				clientSecret = config.Restream.credentials.SEMIPROD.clientSecret;
				break;
				
			case 'SOLOBETA':
				clientId = config.Restream.credentials.SOLOBETA.clientId;
				clientSecret = config.Restream.credentials.SOLOBETA.clientSecret;
				break;

			default:
				clientId = config.Restream.credentials.LOCAL.clientId;
				clientSecret = config.Restream.credentials.LOCAL.clientSecret;
				break;
		}
		var options = {
			method: 'POST',
			uri: config.Restream.URI + config.Restream.endpoints.token,
			headers: {
			'content-type': 'application/x-www-form-urlencoded',
			authorization: 'Basic '+Buffer.from(clientId+':'+clientSecret).toString('base64')
			},
			resolveWithFullResponse: true,
			form: {
				code: event.code,
				redirect_uri: event.redirect_uri,
				grant_type: event.grant_type
			},
			json: true
		};
		let result = await rp(options);
		return result.body;
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: err.error.error.code,
            property:"restream",
            message:err.error.error.message,
        });
	}
}