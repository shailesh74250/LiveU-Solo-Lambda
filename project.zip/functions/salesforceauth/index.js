//Salesforce token
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth,errors} = require("solo-utils");
const config = require('config.json');
const rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;
		const token = await getToken();
		responseBody.data = {
			response: JSON.parse(token),
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;
	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = {handler};
/**
 * @name getToken
 * @description get Salesforce token
 * */
async function getToken() {
	try {
		var options = {};
		if (process.env.ENVIRONMENT == 'dev') {
			options = {
				method: 'POST',
				uri: config.Salesforce.credentials.DEV.URI + config.Salesforce.endpoints.token,
				resolveWithFullResponse: true,
				form: config.Salesforce.credentials.DEV.form
			};
		}
		else if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod') {
			options = {
				method: 'POST',
				uri: config.Salesforce.credentials.QA.URI + config.Salesforce.endpoints.token,
				resolveWithFullResponse: true,
				form: config.Salesforce.credentials.QA.form
			};
		}
		else if (process.env.ENVIRONMENT == 'prod') {
			options = {
				method: 'POST',
				uri: config.Salesforce.credentials.PROD.LOGINURI + config.Salesforce.endpoints.token,
				resolveWithFullResponse: true,
				form: config.Salesforce.credentials.PROD.form
			};
		}
		let result = await rp(options);
		return result.body;
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"salesforce",
            message:err.error[0].message,
        });
	}
}