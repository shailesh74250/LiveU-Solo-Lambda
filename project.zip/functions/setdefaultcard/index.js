'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const card = await updateCard(params);
    const carddetails = await retrieveCard(params);
    const customer = await updateCustomer(params.customer_id, carddetails);
    responseBody.data = {
        response: card,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name updateCard
 * @description set default card details
 * */
async function updateCard(event) {
    try {
        const data = await stripe.customers.update(event.customer_id, {
            default_source: event.card_id
        });
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name retrieveCard
 * @description retrive default card details
 * */
async function retrieveCard(event) {
    try {
        const data = await stripe.customers.retrieveCard(event.customer_id, event.card_id);
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name updateCustomer
 * @description update customer details
 * */
async function updateCustomer(customerId, event) {
    try {
        const data = await stripe.customers.update(customerId, {
            metadata: {
                city: event.address_city,
                country: event.country,
                add_line1: event.address_line1,
                add_line2: event.address_line2,
                zipcode: event.address_zip,
                state: event.address_state
            }
        });
        return data;
    }
    catch (err) {
        throw err;
    }
}
