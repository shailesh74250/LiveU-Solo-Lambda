//delete singular control app
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const body = JSON.parse(event.body);
        const app = await deleteControlapp(body);
        responseBody.data = {
            response: app,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name deleteControlapp
 * @description delete singular control app
 * */
async function deleteControlapp(event) {
    try {
        const params = {
            TableName: "singular_control_app_" + process.env.ENVIRONMENT,
            Key: {
                "id": event.id
            }
        };
        const data = await docClient.delete(params).promise();
        return data;
    }
    catch (err) {

    throw err;
    }
}
