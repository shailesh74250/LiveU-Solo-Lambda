//Edit Singular templates
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const body = JSON.parse(event.body);
        const template = await getTemplates(body);
        if(template.Count){
            template = await updateTemplate(body);
        }
        else{
            template = await createTemplate(body);
        }
        responseBody.data = {
            response: template,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getTemplates
 * @description get singular templates by id
 * */
async function getTemplates(event) {
    try {
        const params = {
            TableName: 'singular_templates_' + process.env.ENVIRONMENT,
            KeyConditionExpression: "#template_id = :template_id",
            ExpressionAttributeNames: {
                "#template_id": "template_id"
            },
            ExpressionAttributeValues: {
                ":template_id": event.id
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name updateTemplate
 * @description update singular templates by id
 * */
async function updateTemplate(event) {
    try {
        const params = {
            TableName: 'singular_templates_' + process.env.ENVIRONMENT,
            Key: {
                "template_id": event.id
            },
            UpdateExpression: "set template = :p",
            ExpressionAttributeValues: {
                ":p": event.template
            },
            ReturnValues: "UPDATED_NEW"
        };
        const data = await docClient.update(params).promise();
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name createTemplate
 * @description create new record of singular template
 * */
async function createTemplate(event) {
    try {
        const params = {
            Item: {
                template_id: event.id,
                template: event.template
            },
            TableName: 'singular_templates_' + process.env.ENVIRONMENT,
        };
        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        throw err;
    }
}