//get singular compositions
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
var config = require('./config.json');
var rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    try {
        const token = await getCompositions(event);
        responseBody.data = {
            response: token,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    }
    catch (err) {
        if(err.statusCode == 401)
            err.statusCode = 403;
        statusCode = err.statusCode;
        err.requestId = context.awsRequestId;
        responseBody.errors = [err];
    }

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }));

module.exports = { handler };

/**
 * @name getProfile
 * @description get singular compositions
 * */
async function getCompositions(event) {
    try {
    var options = {
        method: 'GET',
        uri: config.Singular.APIURI + config.Singular.endpoints.compositions,
        resolveWithFullResponse: true,
        headers: {
            'Authorization': event.headers.Authorization
        },
		json: true
	};
        let result = await rp(options);
        return result.body;
    }
    catch (err) {
        throw err;
    }
}