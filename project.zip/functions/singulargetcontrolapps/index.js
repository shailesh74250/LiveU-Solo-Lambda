//Get control app
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
        const app = await getControlapp(query);
        responseBody.data = {
            response: app,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getControlapp
 * @description get singular control app by id
 * */
async function getControlapp(event) {
    try {
        var params = {};
        if (parseInt(event.id,10) !== 0) {
            params = {
                TableName: "singular_control_app_"+process.env.ENVIRONMENT,
                KeyConditionExpression: "#id = :id",
                ExpressionAttributeNames: {
                    "#id": "id"
                },
                ExpressionAttributeValues: {
                    ":id": parseInt(event.id,10)
                }
            };    
        }
        else if(parseInt(event.id,10) == 0 && !event.license_type)
        {   params = {
                TableName: "singular_control_app_" + process.env.ENVIRONMENT,
                IndexName: "email-index",
                KeyConditionExpression: "#email = :email",
                ExpressionAttributeNames: {
                    "#email": "email"
                },
                ExpressionAttributeValues: {
                    ":email": event.email
                }
            };
        }
        else
        {   params = {
                TableName: "singular_control_app_" + process.env.ENVIRONMENT,
                IndexName: "email-index",
                KeyConditionExpression: "#email = :email",
                FilterExpression: "#license_type= :license_type",
                ExpressionAttributeNames: {
                    "#email": "email",
                    "#license_type": "license_type"
                },
                ExpressionAttributeValues: {
                    ":email": event.email,
                    ":license_type": event.license_type
                }
            };
        }
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {

    throw err;
    }
}