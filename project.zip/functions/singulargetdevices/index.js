//Get device
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
        const device = await getDevice(query);
        responseBody.data = {
            response: device,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getDevice
 * @description get singular device details
 * */
async function getDevice(event) {
    try {
        var params = {};

            	if (event.id != "" && event.id != undefined) {
                    params = {
                        TableName: "singular_device_usage_" + process.env.ENVIRONMENT,
                        FilterExpression: "#id = :id",
                        ExpressionAttributeNames: {
                            "#id": "id"
                        },
                        ExpressionAttributeValues: {
                            ":id": event.id
                        }
                    };
                }
                else
                {
                    if(event.startdate){
                    params = {
	                    TableName: "singular_device_usage_" + process.env.ENVIRONMENT,
	                    IndexName: "email-index",
	                    FilterExpression: "#email = :email and #s_date >= :sdate and #e_date <= :edate",
	                    ExpressionAttributeNames: {
	                        "#email": "email",
	                        "#s_date" : "start_date",
	                        "#e_date" : "end_date"
	                    },
	                    ExpressionAttributeValues: {
	                        ":email": event.email,
	                        ":sdate" : event.startdate,
	                        ":edate" :event.enddate
	                    }
                	};
                    }
                    else{
                        params = {
	                    TableName: "singular_device_usage_" + process.env.ENVIRONMENT,
	                    IndexName: "email-index",
	                    FilterExpression: "#email = :email",
	                    ExpressionAttributeNames: {
	                        "#email": "email"
	                    },
	                    ExpressionAttributeValues: {
	                        ":email": event.email
	                    }
                	};
                    }
                }
        const data = await docClient.scan(params).promise();
        return data.Items;
    }
    catch (err) {

    throw err;
    }
}