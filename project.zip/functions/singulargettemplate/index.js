//get singular template
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
        const template = await getTemplate(query);
        responseBody.data = {
            response: template,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getTemplate
 * @description get singular template by id
 * */
async function getTemplate(event) {
    try {
        const params = {
            TableName: 'singular_templates_' + process.env.ENVIRONMENT,
            KeyConditionExpression: "#template_id = :template_id",
            ExpressionAttributeNames: {
                "#template_id": "template_id"
            },
            ExpressionAttributeValues: {
                ":template_id": event.id
            }
        };

        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {

    throw err;
    }
}