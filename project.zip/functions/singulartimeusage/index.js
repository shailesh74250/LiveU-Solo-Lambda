//get singular device time usage
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
        const usageData = await getTimeUsage(query);
        if (usageData.Count) {
            var totaltime = 0;
            for (var i = 0; i < usageData.Count; i++) {
                if (usageData.Items[i].devicestatus == "Completed") {
                    var edate = new Date(usageData.Items[i].end_date);
                    var sdate = new Date(usageData.Items[i].start_date);
                    var timevalue = Math.abs(edate.getTime() - sdate.getTime());
                    totaltime = timevalue + totaltime;
                }
            }
            responseBody.data = {
                response: totaltime,
                requestId: context.awsRequestId
            };
        }
        statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getTimeUsage
 * @description get singular device time usage
 * */
async function getTimeUsage(event) {
    try {
        var params = {};
                if (event) {
                    if (event.startdate) {
                        params = {
                            TableName: "singular_device_usage_" + process.env.ENVIRONMENT,
                            IndexName: "email-index",
                            FilterExpression: "#email = :email and #s_date >= :sdate and #e_date <= :edate",
                            ExpressionAttributeNames: {
                                "#email": "email",
                                "#s_date": "start_date",
                                "#e_date": "end_date"
                            },
                            ExpressionAttributeValues: {
                                ":email": event.email,
                                ":sdate": event.startdate,
                                ":edate": event.enddate
                            }
                        };
                    }
                    else {
                        params = {
                            TableName: "singular_device_usage_" + process.env.ENVIRONMENT,
                            IndexName: "email-index",
                            FilterExpression: "#email = :email",
                            ExpressionAttributeNames: {
                                "#email": "email"
                            },
                            ExpressionAttributeValues: {
                                ":email": event.email
                            }
                        };
                    }
                }
                else {
                    params = {
                        TableName: "singular_device_usage_" + process.env.ENVIRONMENT
                    };
                }

        const data = await docClient.scan(params).promise();
        return data.Items;
    }
    catch (err) {

    throw err;
    }
}
