//Get singular token
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
var config = require('./config.json');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
        const token = await getToken();
        responseBody.data = {
            response: token,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;


    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getToken
 * @description get singular token
 * */
async function getToken() {
    try {
        const credentials = {
            client: {
                id: config.Singular.clientId,
                secret: config.Singular.clientSecret
            },
            auth: {
                tokenHost: config.Singular.URI
            }
        };
        var oauth2 = require('simple-oauth2').create(credentials);
        const data = await oauth2.clientCredentials.getToken();
        const accessToken = oauth2.accessToken.create(data);
        return accessToken.token;
    }
    catch (err) {
    throw err;
    }
}