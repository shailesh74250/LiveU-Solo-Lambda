//Add singular user details in dynamo
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const user = await addSingularUser(params);
    responseBody.data = {
        response: user,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name addSingularUser
 * * @description add singular user
 * */
async function addSingularUser(user) {
    try {
        const params = {
            Item: {
                email: user.email,
                singularuser_id: user.user_id,
                singularaccount_id: user.account_id
            },
            TableName: 'singular_users',
        };
        const data = await docClient.put(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}
