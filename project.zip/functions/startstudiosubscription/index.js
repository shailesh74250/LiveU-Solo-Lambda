'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
const stripe = require("stripe")(
    process.env.StripeKey
);
const _ = require('lodash');


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    var sub = {};
    const params = JSON.parse(event.body);
    //const params = event.body;
    const details = await getCustomerDetails(params);
    const service = await getService(details, params);
    console.log(service);
    if (service == null || service == undefined) {
          sub = await createSubscription(params);
        const subscription = await insertUserSubscription(params, sub);
    }
    else {
      sub = { errormessage: "Graphics subscription already exists" };
    }

    responseBody.data = {
        response: sub,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };
});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getCustomerDetails
 * @description get customer details
 * */
async function getCustomerDetails(event) {
    try {
        const data = await stripe.customers.retrieve(event.customer_id);
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name getService
 * @description get customer details
 * */
async function getService(details, event) {
    try {
        const data = details.subscriptions.data.length ? (await _.find(details.subscriptions.data, function(o) { return (o.metadata.service_type == event.service_type) })) : null;
        return data;
    }
    catch (err) {
        throw err;
    }
}


/**
 * @name createSubscription
 * @description get all charges of user
 * */
async function createSubscription(event) {
    try {
        const data = await stripe.subscriptions.create({
            customer: event.customer_id,
            plan: event.plan_id,
            coupon: event.coupon,
            tax_percent: event.tax_percent,
            metadata: {
                service_type: event.service_type,
                package_type: event.package_type
            }
        });
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name insertUserSubscription
 * @description get all charges of user
 * */
async function insertUserSubscription(event, subscription) {
    try {
        const params = {
            Item: {
                subscription_id: subscription.id,
                plan_id: event.plan_id,
                customer_id: event.customer_id,
                coupon: event.coupon,
                service_type: event.service_type,
                package_type: event.package_type,
                interval: event.interval,
                is_cancel: false
            },
            TableName: 'user_subscription_' + process.env.ENVIRONMENT
        };

        const data = await docClient.put(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}
