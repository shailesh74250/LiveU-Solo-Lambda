'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
const stripe = require("stripe")(
    process.env.StripeKey
);
const _ = require('lodash');


/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    var subscription = {};
    var sub = {}; 
    const params = JSON.parse(event.body);
   // const params = event.body;
    const details = await getCustomerDetails(params);
    const service = await getService(details, params);
    if (service == null || service == undefined) {
        const canceledsub = await getCanceledSub(params);
        var trialend = (canceledsub) ? 'now' : null ;
        subscription = await createSubscription(params,trialend);
        sub = subscription ? await addSubscription(params, subscription) : null;
    }
    else if (service && ((params.service_type == "lrt" && service.metadata.service_type == "soloconnect") || (params.service_type == "soloconnect" && service.metadata.service_type == "lrt"))) {
        subscription = await updateSubscription(params, service);
        sub = await addSubscription(params, subscription);
    }
    else {
        throw new errors.APIError(404, {
            code: 404,
            property: "startsusbscription",
            message: "Subscription for this unit already exists",
        });  
    }

    responseBody.data = {
        response: subscription,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };



/**
 * @name getCustomerDetails
 * @description get customer details
 * */
async function getCustomerDetails(event) {
    try {
        const data = await stripe.customers.retrieve(event.customer_id);
        return data;
    }
    catch (err) {
        throw err;
    }
}


/**
 * @name getService
 * @description get customer details
 * */
async function getService(details, event) {
    try {
        const data = details.subscriptions.data.length ?
            (event.service_type == "studio" ?
                (await _.find(details.subscriptions.data, function (o) { return (o.metadata.service_type == event.service_type) })) :
                ((event.service_type == "lrt" || event.service_type == "soloconnect") ?
                    (await _.find(details.subscriptions.data, function (o) {
                        return (o.metadata.unit_id == event.unit_id && (o.metadata.service_type == "lrt" || (o.metadata.service_type == "soloconnect" && o.metadata.modem == event.modem)))
                    })) :
                    null)) :
            null;
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name getCanceledSub
 * @description get list of canceled scubription of customer to check for trial period
 * */
async function getCanceledSub(event) {
    try {
        const data = await stripe.subscriptions.list( 
            {
            customer: event.customer_id,
            status: 'canceled'
            } 
        );
        const result = data.data.length ? 
        await _.find(data.data, function (o) { return ((o.metadata.service_type == event.service_type) && o.trial_end && o.trial_start && (o.metadata.service_type == 'studio' ? true : (o.metadata.unit_id == event.unit_id ? true : false)))}) : 
        null;
        return result;
    }
    catch (err) {
        throw err;
    }
}


/**
 * @name createSubscription
 * @description create subscription
 * */
async function createSubscription(event,trialend) {
    try {
        var payload = trialend ? {
            customer: event.customer_id,
            plan: event.plan_id,
            tax_percent: event.tax_percent,
            coupon: event.coupon,
            trial_end : trialend,
            metadata: {
                unit_id: event.unit_id,
                service_type: event.service_type,
                package_type: event.package_type,
                modem: event.modem,
                lrtsn: event.lrt_sn,
                unitsn: event.unit_sn
            }
        } : {
            customer: event.customer_id,
            plan: event.plan_id,
            tax_percent: event.tax_percent,
            coupon: event.coupon,
            metadata: {
                unit_id: event.unit_id,
                service_type: event.service_type,
                package_type: event.package_type,
                modem: event.modem,
                lrtsn: event.lrt_sn,
                unitsn: event.unit_sn
            }
        }
        const data = await stripe.subscriptions.create(payload);
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name addSubscription
 * @description add subscription in dynamo
 * */
async function addSubscription(event, sub) {
    try {
        const params = {
            Item: {
                subscription_id: sub.id,
                plan_id: event.plan_id,
                customer_id: event.customer_id,
                coupon: event.coupon,
                unit_id: event.unit_id,
                service_type: event.service_type,
                package_type: event.package_type,
                modem: event.modem,
                is_cancel: false,
                interval: event.interval,
                is_emailsent : false
            },
            TableName: 'user_subscription_' + process.env.ENVIRONMENT
        };
        const data = await docClient.put(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name updateSubscription
 * @description updgrade/downgrade subscription 
 * */
async function updateSubscription(event, sub_res) {
    try {
        const data = await stripe.subscriptions.update(
            sub_res.id, {
            items: [{
                id: sub_res.items.data[0].id,
                plan: event.plan_id,
                trial_end : 'now',
            }],
            coupon: event.coupon,
            metadata: {
                unit_id: event.unit_id,
                service_type: event.service_type,
                package_type: event.package_type,
                modem: event.modem,
                lrtsn: event.lrt_sn,
                unitsn: event.unit_sn
            }
        });
        return data;
    }
    catch (err) {
        throw err;
    }
}