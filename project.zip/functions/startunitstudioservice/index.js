//start subscription with default card for Studio Services
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const studio = await startService(params);
    responseBody.data = {
        response: studio,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };
});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name startService
 * @description start studio service for unit
 * */
async function startService(event) {
    try {
        const params = {
            Item: {
                id: GetRandomGUID(),
                customer_id: event.customer_id,
                unit_id: event.unit_id,
                package_type: event.package_type,
                interval: event.interval,
                in_use: true,
                start_date: Math.floor(Date.now() / 1000),
                end_date: 'NA'
            },
            TableName: 'user_studio_usage_' + process.env.ENVIRONMENT
        };
        const data = await docClient.put(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}

function GetRandomGUID() {
    var result;
    var i;
    var j;
    result = '';
    for (j = 0; j < 32; j++) {
        if (j == 8 || j == 12 || j == 16 || j == 20) {
            result = result + '-';
        }
        i = Math.floor(Math.random() * 16).toString(16).toUpperCase();
        result = result + i;
    }
    return result;
}
