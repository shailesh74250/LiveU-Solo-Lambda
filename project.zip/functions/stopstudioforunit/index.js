//Stop studio for unit
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
    const res_data = await stopStudio(query);
    responseBody.data = {
        response: res_data,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name stopStudio
 * * @description set studio use for unit as false
 * */
async function stopStudio(event) {
    try {
        const params = {
            TableName: 'user_studio_usage_' + process.env.ENVIRONMENT,
            Key: {
                "id": event.id
            },
            UpdateExpression: "set end_date = :end_date , in_use = :in_use",
            ExpressionAttributeValues: {
                ":end_date": Math.floor(Date.now() / 1000),
                ":in_use": false
            },
            ReturnValues: "UPDATED_NEW"
        };
        const data = await docClient.update(params).promise();
        return data;
    }
    catch (err) {
        throw err;
    }
}
