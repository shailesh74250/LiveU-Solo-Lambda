//storekit get subscription status
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
	region: 'us-east-1'
});
var rp = require('request-promise');
var _ = require('lodash');
var iOSconfig = require('./config.json');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;
	const cancelSubscription = await getCancelledSubscription();
	const result = cancelSubscription.length ? await updateSubscription(cancelSubscription) : { "message": "No updates" }
	responseBody.data = {
		response: result,
		requestId: context.awsRequestId
	};
	statusCode = HttpStatus.OK;
	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}));

module.exports = { handler };

/**
 * @name getCancelledSubscription
 * @description get destination details
 * */
async function getCancelledSubscription() {
	try {
		var curdate = new Date();
		const params = {
			TableName: "user_subscription_" + process.env.ENVIRONMENT,
			IndexName: "type-index",
			KeyConditionExpression: "#type = :type",
			FilterExpression: "#is_cancel = :iscancel and #e_date <= :edate",
			ExpressionAttributeNames: {
				"#type": "type",
				"#e_date": "end_date",
				"#is_cancel": "is_cancel"
			},
			ExpressionAttributeValues: {
				":type": "ios",
				":edate": curdate.getTime(),
				":iscancel": false
			}
		};
		const data = await docClient.query(params).promise();
		return data.Items;
	}
	catch (err) {
		throw err;
	}
}

/**
 * @name updateSubscription
 * @description get destination details
 * */
async function updateSubscription(cancelSubscription) {
	try {
		let receipt_promise = [];
		cancelSubscription.forEach(async function(item) {
			receipt_promise.push(item);
		});
		const result = _.map(receipt_promise, receipt => {
			return verifyReceipt(receipt);
		});
		await Promise.all(result);
		return { message: "Subscriptions updated" };
	}
	catch (err) {
		throw err;
	}
}


/**
 * @name verifyReceipt
 * @description create post on linkedin
 * */
async function verifyReceipt(event) {
	try {
		var options = {
			method: 'POST',
			url: iOSconfig.PRODURI,
			json: true,
			body: {
				"password": iOSconfig.ID,
				"receipt-data": event.receipt
			},
			headers: {
				'content-type': 'application/json',
				'User-Agent': 'LiveU Solo/1.0.0 (iPhone; iOS 11.4; Scale/3.00)'
			}
		};
		let result = await rp(options);
		if (result.status == 21007) {
			var options = {
				method: 'POST',
				url: iOSconfig.URI,
				json: true,
				body: {
					"password": iOSconfig.ID,
					"receipt-data": event.receipt
				},
				headers: {
					'content-type': 'application/json',
					'User-Agent': 'LiveU Solo/1.0.0 (iPhone; iOS 11.4; Scale/3.00)'
				}
			}
			let result = await rp(options);
			if (result.status == 0) {
				var subexpiry = await _.maxBy(result.latest_receipt_info, function(o) { return o.expires_date_ms; });
				const params = result.pending_renewal_info[0].expiration_intent ? {
					TableName: 'user_subscription_' + process.env.ENVIRONMENT,
					Key: {
						"subscription_id": event.subscription_id
					},
					UpdateExpression: "set is_cancel = :h",
					ExpressionAttributeValues: {
						":h": true
					},
					ReturnValues: "ALL_NEW"
				} : {
					TableName: 'user_subscription_' + process.env.ENVIRONMENT,
					Key: {
						"subscription_id": event.subscription_id
					},
					UpdateExpression: "set end_date = :d",
					ExpressionAttributeValues: {
						":d": parseInt(subexpiry.expires_date_ms)
					},
					ReturnValues: "ALL_NEW"
				};

				const data = await docClient.update(params).promise();
				return data;
			}
			else {
				return null;
			}
		}
		else {
			if (result.status == 0) {
				var subexpiry = await _.maxBy(result.latest_receipt_info, function(o) { return o.expires_date_ms; });
				const params = result.pending_renewal_info[0].expiration_intent ? {
					TableName: 'user_subscription_' + process.env.ENVIRONMENT,
					Key: {
						"subscription_id": event.subscription_id
					},
					UpdateExpression: "set is_cancel = :h",
					ExpressionAttributeValues: {
						":h": true
					},
					ReturnValues: "ALL_NEW"
				} : {
					TableName: 'user_subscription_' + process.env.ENVIRONMENT,
					Key: {
						"subscription_id": event.subscription_id
					},
					UpdateExpression: "set end_date = :d",
					ExpressionAttributeValues: {
						":d": parseInt(subexpiry.expires_date_ms)
					},
					ReturnValues: "ALL_NEW"
				};

				const data = await docClient.update(params).promise();
				return data;
			}
			else {
				return null;
			}
		}
	}
	catch (err) {
		throw err;
	}
}
