const Memcached = require('memcached');
const { errors } = require("solo-utils");
const HttpStatus = require('http-status-codes');
const memcached = new Memcached(process.env.ConfigEndpoint);

exports.handler = async (event, context) => {
	console.log(event)
	let responseBody = {};
	try {
		const data = await storeToken(event);
		responseBody.data = data;
	}
	catch (err) {
		responseBody.errors = [err];
	}

	return responseBody;

};

function storeToken(event) {
	return new Promise((resolve, reject) => {
		memcached.set(event.username, event.token, 14400, function (err) {
			if (err) {
				reject(new errors.APIError(HttpStatus.BAD_REQUEST, {
					code: null,
					message: err.message,
				}));
			}
			else
				resolve({
					"status": HttpStatus.OK
				});
		});
	});
}