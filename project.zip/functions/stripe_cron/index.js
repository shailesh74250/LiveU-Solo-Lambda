//Cron job for annual subscription
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
var _ = require('lodash');

/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const yearlySubscription = await getYearlySubscription();
    const plans = await getPlans();

    const basictime = await _.find(plans.data, function(o) {
        return o.metadata.package_type === "basic" && o.metadata.service_type === "studio" && o.interval === "year";
    });

    const advancetime = await _.find(plans.data, function(o) {
        return o.metadata.package_type === "advance" && o.metadata.service_type === "studio" && o.interval === "year";
    });

    const updatedLicenses = yearlySubscription.length ? await updateSubscriptions(yearlySubscription, basictime, advancetime) : { "message": "No yearly " };

    responseBody.data = {
        response: updatedLicenses,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }));

module.exports = { handler };


async function getYearlySubscription() {
    try {

        var params = {
            TableName: "user_licence_" + process.env.ENVIRONMENT,
            IndexName: "interval-index",
            KeyConditionExpression: "#interval = :interval",
            ExpressionAttributeNames: {
                "#interval": "interval"
            },
            ExpressionAttributeValues: {
                ":interval": "year"
            }
        };

        const data = await docClient.query(params).promise();
        return data.Items;

    }
    catch (err) {
        throw err;
    }
}

/**
 * @name getPlans
 * @description get plans 
 * */
async function getPlans() {
    try {
        const data = await stripe.plans.list();
        return data;
    }
    catch (err) {
        throw err;
    }
}

async function updateUserLicense(params) {
    try {
        console.log(params);
        const data = await docClient.update(params).promise();
        return data;

    }
    catch (err) {
        throw err;
    }
}

async function updateSubscriptions(yearlySubscription, basictime, advancetime) {
    try {
        var addtime;
        let subscription_promise = [];
        yearlySubscription.forEach(function(item) {
            if (item.licence_type == basictime.metadata.package_type) {
                addtime = basictime.metadata.seconds / 12;
            }
            else {
                addtime = advancetime.metadata.seconds / 12;
            }

            //date of yearly subscription
            var sub_date = new Date(item.added_on * 1000);
            var cron_date;
            //date of last cron job
            if (item.last_crondate) {
                cron_date = new Date(item.last_crondate * 1000);
            }
            else {
                cron_date = new Date(item.added_on * 1000);
            }

            //current date
            var cur_date = new Date();

            var params = {
                TableName: 'user_licence_' + process.env.ENVIRONMENT,
                Key: {
                    "customer_id": item.customer_id
                },
                UpdateExpression: "set starter_bucket_hours = :h, last_crondate = :u",
                ExpressionAttributeValues: {
                    ":h": addtime,
                    ":u": Math.floor(new Date() / 1000).toString()
                }
            };
            if (sub_date.getDate() == cur_date.getDate() && ((cur_date.getMonth() - cron_date.getMonth() == 1 && cur_date.getYear() == cron_date.getYear()) || (cur_date.getMonth() == 0 && cron_date.getMonth() == 11 && cur_date.getYear() - cron_date.getYear() == 1))) {
                subscription_promise.push(params);
            }
            else if (cron_date.getMonth() == 0 && ((cur_date.getMonth() - cron_date.getMonth() == 1 && cur_date.getYear() == cron_date.getYear()) || (cur_date.getMonth() == 0 && cron_date.getMonth() == 11 && cur_date.getYear() - cron_date.getYear() == 1))) {
                if ((sub_date.getDate() == 29 || sub_date.getDate() == 30 || sub_date.getDate() == 31)) {
                    if (sub_date.getYear() % 4 == 0) {
                        if (cur_date.getDate() == 29) {
                            subscription_promise.push(params);
                        }
                        else {
                            console.log("No1");
                        }
                    }
                    else {
                        if (cur_date.getDate() == 28) {

                            subscription_promise.push(params);
                        }
                        else {
                            console.log("No2");
                        }
                    }
                }
                else {
                    console.log("No3");
                }
            }
            else if (sub_date.getDate() == 31 && ((cur_date.getMonth() - cron_date.getMonth() == 1 && cur_date.getYear() == cron_date.getYear()) || (cur_date.getMonth() == 0 && cron_date.getMonth() == 11 && cur_date.getYear() - cron_date.getYear() == 1))) {
                if (cron_date.getMonth() == 11) {
                    if (cur_date.getDate == 31) {

                        subscription_promise.push(params);
                    }
                    else {
                        console.log("No4");
                    }
                }
                else if (cur_date.getDate() == 30 && (cur_date.getMonth() == 3 || cur_date.getMonth() == 5 || cur_date.getMonth() == 8 || cur_date.getMonth() == 10)) {
                    subscription_promise.push(params);
                }
                else {
                    console.log("No5");
                }
            }
            else {
                console.log("No6");
            }

        })
        const result = await _.map(subscription_promise, sub => {
            return updateUserLicense(sub);
        });
        const res = await Promise.all(result);
        return res;
    }
    catch (err) {
        throw err;
    }
}
