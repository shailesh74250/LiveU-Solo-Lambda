//start subscription with default card for Studio Services
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);
const Promise = require('bluebird');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
const fs = require('fs');
const fs_extra = require('fs-extra');
const lambda = new AWS.Lambda({
    region: 'us-east-1'
});
var _ = require('lodash');
var config = require('./config.json');
var rp = require('request-promise');
var ua = require('universal-analytics');
const Rollbar = require('rollbar');
let rollbar = new Rollbar({ accessToken: (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'semiprod') ? config.rollbar.qa : config.rollbar.prod });
rollbar.configure({
    enabled: true,
    autoInstrument: true,
    maxTelemetryEvents: 20,
    scrubTelemetryInputs: false,
    payload: {
        environment: ((process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'semiprod') ? 'Staging' : 'Production')
    }
});
let rollbarErr = {};
let rollbarWarn = {};

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event;
    const result = await commonFunction(params);
    responseBody.data = {
        response: result,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }));

module.exports = { handler };

async function commonFunction(event) {
    try {
        let result;
        let customer;
        let details;
        let subscriptions;
        let license;
        let updatedlicense;
        let deletesubscription;
        let studio;
        let updatedstudio;
        let source;
        let deleteddcustomer;
        let sfauth;
        let sfregister;
        let sf_token;
        let invoice;
        let refund;

        switch (event.type) {
            case "customer.subscription.deleted":
                switch (event.data.object.items.data[0].plan.metadata.service_type) {

                    case "lrt":
                        customer = await getCustomer(event.data.object.customer);
                        subscriptions = customer ? await updateUserSubscription(event.data.object.id) : null;
                        if (customer) {
                            if (subscriptions) {
                                result = { message: "LRT subscription cancelled successfully" };
                            }
                            else {
                                result = { message: "No LRT subscription" };
                            }
                        }
                        else {
                            result = { message: "Customer not found" };
                        }
                        return result;

                    case "studio":
                        customer = await getCustomer(event.data.object.customer);
                        subscriptions = customer ? await updateUserSubscription(event.data.object.id) : null;
                        license = customer ? await getLicenceByCustomerId(event.data.object.customer) : null;
                        updatedlicense = license ? await deleteUserLicence(license[0]) : null;
                        studio = license ? await getStudioUsage(event.data.object.customer) : null;
                        updatedstudio = studio ? updateAllStudioUsage(studio) : null;
                        if (customer) {
                            if (subscriptions && updatedlicense && updatedstudio) {
                                result = { message: "Subscription updated successfully" };
                            }
                            else {
                                result = { message: "Error deleting Studio subscription" };
                            }
                        }
                        else {
                            result = { message: "Customer not found" };
                        }
                        return result;

                    case "soloconnect":
                        customer = await getCustomer(event.data.object.customer);
                        subscriptions = customer ? await updateUserSubscription(event.data.object.id) : null;
                        if (customer) {
                            if (subscriptions) {
                                result = { message: "Solo connect subscription cancelled successfully" };
                            }
                            else {
                                result = { message: "No Solo connect subscription" };
                            }
                        }
                        else {
                            result = { message: "Customer not found" };
                        }
                        return result;
                }
                return { message: "Subscription type doesn't exist" };

            case "invoice.payment_succeeded":
                switch (event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.metadata.service_type) {

                    case "lrt":
                        customer = await getCustomer(event.data.object.customer);
                        details = customer ? await getStripeCustomerDetails(event.data.object.customer) : null;
                        sfauth = details ? await sfAuth(event) : null;
                        sf_token = sfauth ? (sfauth.access_token ? sfauth.access_token : JSON.parse(sfauth).access_token) : null;
                        sfregister = (details && sfauth) ? await sfRegisterLRT(event, details, sf_token) : null;
                        if (customer) {
                            if (details && sfauth) {
                                if (sfregister) {
                                    result = { message: "Success - LRT SF api called successfully" };
                                }
                                else {
                                    result = { message: "SF LRT register API failed" };
                                }
                            }
                            else {
                                if (details) {
                                    result = { message: "SF auth failed" };
                                }
                                else {
                                    result = { message: "Customer details not retrived" };
                                }
                            }
                        }
                        else {
                            result = { message: "Customer not found" };
                        }

                        return result;

                    case "studio":
                        customer = await getCustomer(event.data.object.customer);
                        license = customer ? await getLicenceByCustomerId(event.data.object.customer) : null;
                        updatedlicense = license ? await updateUserLicense(event, license[0].extra_hours) : null;
                        details = customer ? await getStripeCustomerDetails(event.data.object.customer) : null;
                        sfauth = details ? await sfAuth(event) : null;
                        sf_token = sfauth ? (sfauth.access_token ? sfauth.access_token : JSON.parse(sfauth).access_token) : null;
                        console.log(sf_token);
                        sfregister = (details && sfauth) ? await sfRegisterStudio(event, details, sf_token) : null;
                        console.log(sfregister);
                        if (customer) {
                            if (license) {
                                if (updatedlicense) {
                                    if (details && sfauth) {
                                        if (sfregister) {
                                            result = { message: "Success - SF Studio api called successfully" };
                                        }
                                        else {
                                            result = { message: "SF Studio register API failed" };
                                        }
                                    }
                                    else {
                                        if (details) {
                                            result = { message: "SF auth failed" };
                                        }
                                        else {
                                            result = { message: "Stripe customer details not retrived" };
                                        }
                                    }
                                }
                                else {
                                    if (details && sfauth && sfregister) {
                                        result = { message: "Studio license not updated and SF Studio api called successfully" };
                                    }
                                    else {
                                        result = { message: "Studio license not updated and SF api failed" };
                                    }
                                }
                            }
                            else {
                                if (details && sfauth && sfregister) {
                                    result = { message: "Studio license not retrived and SF api called successfully" };
                                }
                                else {
                                    result = { message: "Studio license not retrived and Sf api failed" };
                                }
                            }
                        }
                        else {
                            result = { message: "Customer not found" };
                        }

                        return result;

                    case "soloconnect":
                        customer = await getCustomer(event.data.object.customer);
                        details = customer ? await getStripeCustomerDetails(event.data.object.customer) : null;
                        sfauth = details ? await sfAuth(event) : null;
                        sf_token = sfauth ? (sfauth.access_token ? sfauth.access_token : JSON.parse(sfauth).access_token) : null;
                        sfregister = (details && sfauth) ? await sfRegisterSoloConnect(event, details, sf_token) : null;
                        if (customer) {
                            if (details && sfauth) {
                                if (sfregister) {
                                    result = { message: "Success - Solo connect SF api called successfully" };
                                }
                                else {
                                    result = { message: "SF Solo connect register API failed" };
                                }
                            }
                            else {
                                if (details) {
                                    result = { message: "SF auth failed" };
                                }
                                else {
                                    result = { message: "Customer details not retrived" };
                                }
                            }
                        }
                        else {
                            result = { message: "Customer not found" };
                        }

                        return result;

                }
                return { message: "Subscription type doesn't exist" };

            case "customer.deleted":
                customer = await getCustomer(event.data.object.id);
                deleteddcustomer = customer ? await deleteStripeCustomer(event) : null;
                subscriptions = customer ? await scanUserSubscription(event.data.object.id) : null;
                deletesubscription = subscriptions ? await deleteSubscriptions(subscriptions, event) : null;
                if (customer) {
                    if (deleteddcustomer) {
                        if (deletesubscription) {
                            result = { message: "Success - Customer and subscription deleted successfully" };
                        }
                        else {
                            result = { message: "Customer deleted and  no subscription found" };
                        }
                    }
                    else {
                        result = { message: "Customer not deleted" };
                    }
                }
                else {
                    result = { message: "Customer not found" };
                }
                return result;

            case "charge.failed":
                result = await insertChargeFailureDetails(event);
                return { message: "Charge failure details inserted successfully" };

            case "invoice.payment_failed":
                result = await insertInvoiceFailureDetails(event);
                return { message: "Invoice failure details inserted successfully" };

            case "customer.source.updated":
                customer = await getCustomer(event.data.object.customer);
                details = customer ? await getStripeCustomerDetails(event.data.object.customer) : null;
                source = (details && (details.default_source == event.data.object.id)) ? await updateCustomer(event.data.object.customer, event) : null;
                if (customer) {
                    if (details) {
                        if (source) {
                            result = { message: "Success - Customer source updated successfully" };
                        }
                        else {
                            result = { message: "Not default card" };
                        }
                    }
                    else {
                        result = { message: "Stripe customer details not found" };
                    }
                }
                else {
                    result = { message: "No customer found" };
                }
                return result;

            case "charge.refunded":
                switch (event.data.object.description) {

                    case "Verification Charge":
                        return { message: "Verification Charge" };

                    default:
                        sfauth = await sfAuth(event);
                        sf_token = sfauth ? (sfauth.access_token ? sfauth.access_token : JSON.parse(sfauth).access_token) : null;
                        details = sfauth ? await getStripeCustomerDetails(event.data.object.customer) : null;
                        invoice = (sfauth && event.data.object.invoice) ? await getInvoiceDetails(event.data.object.invoice) : await getPlans();
                        let match = event.data.object.invoice ? null : _.find(invoice.data, function (o) {
                            return o.interval === "month" && event.data.object.metadata.license_type == o.metadata.package_type;
                        });
                        let tax = event.data.object.invoice ? invoice.tax / 100 : event.data.object.metadata.tax_amount;
                        let payload = event.data.object.invoice ? ((invoice.lines.data[invoice.lines.total_count - 1].metadata.service_type == "studio") ? {
                            type_of_action: "Customer Service",
                            service_type: "Graphics",
                            part_number: invoice.lines.data[invoice.lines.total_count - 1].plan.metadata.part_number,
                            hours: (invoice.lines.data[invoice.lines.total_count - 1].plan.metadata.seconds) / 3600,
                            extra_hours: 0,
                            unit_id: "",
                            interval: invoice.lines.data[invoice.lines.total_count - 1].plan.interval == "year" ? 12 : 1,
                            taxamount: tax
                        } : {
                                type_of_action: "Service",
                                service_type: "LRT",
                                part_number: invoice.lines.data[invoice.lines.total_count - 1].plan.metadata.part_number,
                                hours: 0,
                                extra_hours: 0,
                                unit_id: invoice.lines.data[invoice.lines.total_count - 1].metadata.unit_id,
                                interval: invoice.lines.data[invoice.lines.total_count - 1].plan.interval == "year" ? 12 : 1,
                                taxamount: tax
                            }) : {
                                type_of_action: "Customer Service",
                                service_type: "Graphics",
                                part_number: match.metadata.extra_part_number,
                                hours: 0,
                                extra_hours: match.metadata.extra_seconds / 3600,
                                unit_id: "",
                                interval: -1,
                                taxamount: tax
                            };
                        refund = (sf_token && invoice && details) ? chargeRefunded(event, details, sf_token, payload) : null;
                        if (sfauth) {
                            if (details && invoice) {
                                if (refund) {
                                    result = { message: "Success - Charge refunded and Sf called successfully" };
                                }
                                else {
                                    result = { message: "Sf refund api failed" };
                                }
                            }
                            else {
                                if (details) {
                                    result = { message: "Stripe customer details not retrieved" };
                                }
                                else {
                                    result = { message: "Invoice or plan not retrieved" };
                                }
                            }
                        }
                        else {
                            result = { message: "SF auth failed" };
                        }
                        return result;
                }

            case "customer.subscription.updated":
                if ((!event.data.previous_attributes.current_period_end && !event.data.previous_attributes.current_period_start && !event.data.object.cancel_at_period_end && event.data.previous_attributes.items)) {
                    event.data.object.paid = true;
                    event.data.object.amount_paid = 0;
                    event.data.object.tax = 0;
                    switch (event.data.object.items.data[event.data.object.items.total_count - 1].plan.metadata.service_type) {
                        case "lrt":
                            customer = await getCustomer(event.data.object.customer);
                            details = customer ? await getStripeCustomerDetails(event.data.object.customer) : null;
                            sfauth = details ? await sfAuth(event) : null;
                            sf_token = sfauth ? (sfauth.access_token ? sfauth.access_token : JSON.parse(sfauth).access_token) : null;
                            sfregister = (details && sfauth) ? await sfRegisterLRT(event, details, sf_token) : null;
                            if (customer) {
                                if (details && sfauth) {
                                    if (sfregister) {
                                        result = { message: "Success - LRT SF api called successfully" };
                                    }
                                    else {
                                        result = { message: "SF LRT register API failed" };
                                    }
                                }
                                else {
                                    if (details) {
                                        result = { message: "SF auth failed" };
                                    }
                                    else {
                                        result = { message: "Customer details not retrived" };
                                    }
                                }
                            }
                            else {
                                result = { message: "Customer not found" };
                            }

                            return result;

                        case "studio":
                            customer = await getCustomer(event.data.object.customer);
                            details = customer ? await getStripeCustomerDetails(event.data.object.customer) : null;
                            sfauth = details ? await sfAuth(event) : null;
                            sf_token = sfauth ? (sfauth.access_token ? sfauth.access_token : JSON.parse(sfauth).access_token) : null;
                            console.log(sf_token);
                            sfregister = (details && sfauth) ? await sfRegisterStudio(event, details, sf_token) : null;
                            console.log(sfregister);
                            if (customer) {
                                if (license) {
                                    if (updatedlicense) {
                                        if (details && sfauth) {
                                            if (sfregister) {
                                                result = { message: "Success - SF Studio api called successfully" };
                                            }
                                            else {
                                                result = { message: "SF Studio register API failed" };
                                            }
                                        }
                                        else {
                                            if (details) {
                                                result = { message: "SF auth failed" };
                                            }
                                            else {
                                                result = { message: "Stripe customer details not retrived" };
                                            }
                                        }
                                    }
                                    else {
                                        if (details && sfauth && sfregister) {
                                            result = { message: "Studio license not updated and SF Studio api called successfully" };
                                        }
                                        else {
                                            result = { message: "Studio license not updated and SF api failed" };
                                        }
                                    }
                                }
                                else {
                                    if (details && sfauth && sfregister) {
                                        result = { message: "Studio license not retrived and SF api called successfully" };
                                    }
                                    else {
                                        result = { message: "Studio license not retrived and Sf api failed" };
                                    }
                                }
                            }
                            else {
                                result = { message: "Customer not found" };
                            }

                            return result;

                        case "soloconnect":
                            customer = await getCustomer(event.data.object.customer);
                            details = customer ? await getStripeCustomerDetails(event.data.object.customer) : null;
                            sfauth = details ? await sfAuth(event) : null;
                            sf_token = sfauth ? (sfauth.access_token ? sfauth.access_token : JSON.parse(sfauth).access_token) : null;
                            sfregister = (details && sfauth) ? await sfRegisterSoloConnect(event, details, sf_token) : null;
                            if (customer) {
                                if (details && sfauth) {
                                    if (sfregister) {
                                        result = { message: "Success - Solo connect SF api called successfully" };
                                    }
                                    else {
                                        result = { message: "SF Solo connect register API failed" };
                                    }
                                }
                                else {
                                    if (details) {
                                        result = { message: "SF auth failed" };
                                    }
                                    else {
                                        result = { message: "Customer details not retrived" };
                                    }
                                }
                            }
                            else {
                                result = { message: "Customer not found" };
                            }

                            return result;

                    }
                    return { message: "Subscription type doesn't exist" };
                }
                else {
                    return { message: "Default subscription updated" };
                }

            default:
                return { message: "Default" };
        }
    }
    catch (err) {
        console.log(err);
        rollbarErr.description = err.message;
        rollbar.error("Stripe_web_hooks:" + err.message, rollbarErr);
        throw err;
    }
}

/**
 * getCustomer
 * @param {string} customer_id
 */
async function getCustomer(customer_id) {
    try {
        var params = {
            TableName: "stripe_users_" + process.env.ENVIRONMENT,
            KeyConditionExpression: "#customer_id = :customer_id",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id
            }
        };

        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("GetCustomer error:" + err.message, rollbarErr);
        }
        throw err;
    }
}


/**
 * scanUserSubscription
 * @param {string} customer_id
 */
async function scanUserSubscription(customer_id) {
    try {
        var params = {
            TableName: 'user_subscription_' + process.env.ENVIRONMENT,
            IndexName: "customer_id-index",
            KeyConditionExpression: "#customer_id = :customer_id",
            FilterExpression: "#is_cancel = :is_cancel",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id",
                "#is_cancel": "is_cancel"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id,
                ":is_cancel": false
            }
        };

        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("scanUserSubscription error:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * deleteSubscriptions
 * @param {object} subscription
 */
async function deleteSubscriptions(subscriptions, event) {
    try {
        const sub = await updateAllSubscriptions(subscriptions);
        const license = await getLicenceByCustomerId(event.data.object.id);
        const studio = license ? await getStudioUsage(event.data.object.id) : null;
        const updatedsubscriptions = license ? await deleteUserLicence(license[0]) : null;
        const updatedstudio = studio ? await updateAllStudioUsage(studio) : null;
        return { message: "Subscription deleted successfully" };
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("deleteSubscriptions error:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * updateAllSubscriptions
 * @param {object} subscription
 */
async function updateAllSubscriptions(subscriptions) {
    try {
        const sub = await _.map(subscriptions, item => {
            return updateUserSubscription(item.subscription_id);
        });
        await Promise.all(sub);
        return { message: "Updated all subscriptions" };
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("updateAllSubscriptions:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * updateAllStudioUsage
 * @param {object} studio
 */
async function updateAllStudioUsage(studio) {
    try {
        const updatedstudio = studio ? await _.map(studio, item => {
            return updateStudioUsage(item.id);
        }) : null;
        await Promise.all(updatedstudio);
        return { message: "Updated all studio usages" };
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("updateAllStudioUsage:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * updateStudioUsage
 * @param {string} id
 */
async function updateStudioUsage(id) {
    try {
        var params = {
            TableName: 'user_studio_usage_' + process.env.ENVIRONMENT,
            Key: {
                "id": id
            },
            ConditionExpression: "id = :id",
            ExpressionAttributeValues: {
                ":id": id
            }
        };

        const data = await docClient.delete(params).promise();
        return { message: "Deleted" };

    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("updateStudioUsage:" + err.message, rollbarErr);
        }
        throw err;
    }
}


/**
 * updateUserLicense
 * @param {object} event
 * @param {number} extratime
 */
async function updateUserLicense(event, extratime) {
    try {
        var time = (event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.interval == "year") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.metadata.seconds / 12 : event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.metadata.seconds;

        var params = {
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
            Key: {
                "customer_id": event.data.object.customer
            },
            ConditionExpression: 'subscription_id = :subscription_id',
            UpdateExpression: "set starter_bucket_hours = :s , extra_hours = :c , last_crondate = :l , added_on = :a",
            ExpressionAttributeValues: {
                ":s": time,
                ":subscription_id": event.data.object.subscription,
                ":c": extratime,
                ":l": event.data.object.lines.data[event.data.object.lines.total_count - 1].period.start,
                ":a": event.data.object.lines.data[event.data.object.lines.total_count - 1].period.start
            },
            ReturnValues: "UPDATED_NEW"
        };

        const data = await docClient.update(params).promise();
        return data;

    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("updateUserLicense:" + err.message, rollbarErr);
        }
        throw err;
    }
}


/**
 * getLicenceByCustomerId
 * @param {string} customer_id
 */
async function getLicenceByCustomerId(customer_id) {
    try {
        var params = {
            TableName: "user_licence_" + process.env.ENVIRONMENT,
            KeyConditionExpression: "#customer_id = :customer_id",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id
            }
        };

        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else { return null; }
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("getLicenceByCustomerId:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * deleteUserLicence
 * @param {object} data
 */
async function deleteUserLicence(license) {
    try {
        var params = {
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
            Key: {
                "customer_id": license.customer_id
            },
            ConditionExpression: 'customer_id = :customer_id AND subscription_id = :subscription_id',
            ExpressionAttributeValues: {
                ":customer_id": license.customer_id,
                ":subscription_id": license.subscription_id
            }
        };
        const data = await docClient.delete(params).promise();
        return { message: "Deleted" };
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("deleteUserLicence:" + err.message, rollbarErr);
        }
        throw err;

    }
}

/**
 * updateUserSubscription
 * @param {string} subscription_id
 */
async function updateUserSubscription(subscription_id) {
    try {
        var params = {
            TableName: 'user_subscription_' + process.env.ENVIRONMENT,
            Key: {
                "subscription_id": subscription_id
            },
            ConditionExpression: 'subscription_id = :subscription_id',
            UpdateExpression: "set is_cancel = :c",
            ExpressionAttributeValues: {
                ":c": true,
                ":subscription_id": subscription_id
            },
            ReturnValues: "UPDATED_NEW"
        };

        const data = await docClient.update(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("updateUserSubscription:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * getStudioUsage
 * @param {string} customer_id
 */
async function getStudioUsage(customer_id) {
    try {
        var params = {
            TableName: 'user_studio_usage_' + process.env.ENVIRONMENT,
            IndexName: "customer_id-index",
            KeyConditionExpression: "#customer_id= :customer_id",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id
            }
        };

        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("getStudioUsage:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * insertChargeFailureDetails
 * @param {object} event
 */
async function insertChargeFailureDetails(event) {
    try {

        var params = {
            Item: {
                id: GetRandomGUID(),
                date: event.created,
                customer_id_name: event.data.object.source.name,
                type: "Charge failure",
                description: event.data.object.description,
                subscription_charge_id: event.data.object.id,
                event: event.data.object.failure_code
            },
            TableName: 'payment_failure_details_' + process.env.ENVIRONMENT,
        };

        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("insertChargeFailureDetails:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * insertInvoiceFailureDetails
 * @param {object} event
 */
async function insertInvoiceFailureDetails(event) {
    try {

        var params = {
            Item: {
                id: GetRandomGUID(),
                date: event.created,
                customer_id_name: event.data.object.customer,
                type: "Invoice failure",
                subscription_charge_id: event.data.object.lines.data[0].id,
                event: event.type,
                description: event.data.object.lines.data[0].metadata.service_type
            },
            TableName: 'payment_failure_details_' + process.env.ENVIRONMENT,
        };

        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("insertInvoiceFailureDetails:" + err.message, rollbarErr);
        }
        throw err;
    }
}


/**
 * deleteStripeCustomer
 * @param {object} event
 */
async function deleteStripeCustomer(event) {
    try {
        var params = {
            TableName: 'stripe_users_' + process.env.ENVIRONMENT,
            Key: {
                "customer_id": event.data.object.id
            },
            ConditionExpression: 'customer_id = :customer_id',
            ExpressionAttributeValues: {
                ":customer_id": event.data.object.id
            }
        };
        const data = await docClient.delete(params).promise();
        return { message: "Deleted" };
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.description = err.message;
            rollbar.error("deleteStripeCustomer:" + err.message, rollbarErr);
        }
        throw err;
    }
}


/**
 * updateCustomer
 * @param {object} add_info
 * @string {object} customer_id
 */
async function updateCustomer(customer_id, add_info) {
    try {
        const data = await stripe.customers.update(customer_id, {
            metadata: {
                city: add_info.data.object.address_city,
                country: add_info.data.object.country,
                add_line1: add_info.data.object.address_line1,
                add_line2: add_info.data.object.address_line2,
                zipcode: add_info.data.object.address_zip,
                state: add_info.data.object.address_state
            }
        });
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * getStripeCustomerDetails
 * @param {string} customer_id
 */
async function getStripeCustomerDetails(customer_id) {
    try {
        const data = await stripe.customers.retrieve(customer_id);
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * getInvoiceDetails
 * @param {string} invoice_id
 */
async function getInvoiceDetails(invoice_id) {
    try {
        const data = await stripe.invoices.retrieve(invoice_id)
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * getPlans
 */
async function getPlans() {
    try {
        const data = await stripe.plans.list();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * sfAuth
 * @param {object} event
 */
async function sfAuth(event) {
    try {
        var options = {};
        if (process.env.ENVIRONMENT == 'dev') {
            options = {
                method: 'POST',
                uri: config.Salesforce.credentials.DEV.URI + config.Salesforce.endpoints.token,
                resolveWithFullResponse: true,
                form: config.Salesforce.credentials.DEV.form
            };
        }
        else if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod') {
            options = {
                method: 'POST',
                uri: config.Salesforce.credentials.QA.URI + config.Salesforce.endpoints.token,
                resolveWithFullResponse: true,
                form: config.Salesforce.credentials.QA.form
            };
        }
        else if (process.env.ENVIRONMENT == 'prod') {
            options = {
                method: 'POST',
                uri: config.Salesforce.credentials.PROD.URI + config.Salesforce.endpoints.token,
                resolveWithFullResponse: true,
                form: config.Salesforce.credentials.PROD.form
            };
        }
        const data = await rp(options);
        console.log(data.body);
        return data.body;
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.status = err.status;
            rollbarErr.description = err.message;
            rollbar.error("SFauth error:" + err.message, rollbarErr);
        }
        throw err;
    }
}


/**
 * sfRegisterLRT
 * @param {object} event
 * @param {object} add_info
 * @param {number} sf_auth
 */
async function sfRegisterLRT(event, add_info, sf_auth) {
    try {

        var visitor = ua(config.Verifyunit.googleAnalyticsID);
        var duration = (event.type == "invoice.payment_succeeded") ?
            ((event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.interval == "year") ? 12 : (event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.interval == "month" ? 1 : 0)) :
            ((event.data.object.items.data[event.data.object.items.total_count - 1].plan.interval == "year") ? 12 : (event.data.object.items.data[event.data.object.items.total_count - 1].plan.interval == "month" ? 1 : 0));
        var url = (process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod') ? config.Verifyunit.DEV.URI + config.Verifyunit.endpoints.isvalidunit : config.Verifyunit.PROD.URI + config.Verifyunit.endpoints.isvalidunit;
        var r_key = "";
        var promocode = "";

        if (event.data.object.discount) {
            var coupon = event.data.object.discount.coupon.id;
            if (coupon.substring(0, 4) == "LRT_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 7) == "GRHADV_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 7) == "GRHBAS_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "SC2M_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "SC3M_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "solo-") {
                promocode = coupon;
            }
        }

        var options = {
            method: 'POST',
            uri: url,
            resolveWithFullResponse: true,
            headers: {
                'Authorization': "Bearer " + sf_auth
            },
            body: {
                "SerialNumber": "",
                "service_type": "LRT",
                "TypeOfAction": "Service",
                "unit_id": (event.type == "invoice.payment_succeeded") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unit_id : event.data.object.items.data[event.data.object.items.total_count - 1].metadata.unit_id,
                "part_number": (event.type == "invoice.payment_succeeded") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.metadata.part_number : event.data.object.items.data[event.data.object.items.total_count - 1].plan.metadata.part_number,
                "hours": 0,
                "extraHours": 0,
                "email": add_info.email,
                "customerId": event.data.object.customer,
                "timestamp": Math.floor(Date.now() / 1000),
                "interval": duration,
                "amount": (event.data.object.amount_paid / 100),
                "currencyCode": event.data.object.currency ? event.data.object.currency.toUpperCase() : 'USD',
                "paid": event.data.object.paid,
                "address_city": add_info.metadata.city,
                "address_country": add_info.metadata.country,
                "address_line1": add_info.metadata.add_line1,
                "address_line2": add_info.metadata.add_line2,
                "address_state": add_info.metadata.state,
                "address_zip": add_info.metadata.zipcode,
                "DealNumber": (event.type == "invoice.payment_succeeded") ? event.data.object.number : event.id.split('_').pop(),
                "RegistrationKey": r_key,
                "PromotionalCodes": promocode,
                "SalesTax": (event.data.object.tax / 100),
                "LRTSerialNumber": ""
            },
            json: true
        };
        console.log(options.body);
        const data = await rp(options);
        let obj = JSON.parse(data.body);
        console.log(obj);
        if (obj.result != "success") {
            if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
                rollbarWarn = {
                    "description": (obj.result ? obj.result : 'No LRT message'),
                    "payload": (options.body),
                    "sfresponse": data,
                    "user": (add_info.email ? add_info.email : 'user not found'),
                    "unitId": (event.type == "invoice.payment_succeeded") ? (event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unit_id) : (event.data.object.items.data[event.data.object.items.total_count - 1].metadata.unit_id)
                };
                rollbar.warning(
                    "sfRegisterLRT: description: " + (obj.result ? obj.result : 'No LRT message') + " user: " + (add_info.email ? add_info.email : 'user not found') + " unitId: " + (event.type == "invoice.payment_succeeded") ? (event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unit_id) : (event.data.object.items.data[event.data.object.items.total_count - 1].metadata.unit_id),
                    rollbarWarn);
            }
            var label = JSON.stringify(options.body);
            visitor.event("Salesforce Register endpoint-" + process.env.ENVIRONMENT, obj.result, label, 1).send();
        }
        return data.body;
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.status = err.status;
            rollbarErr.description = err.message;
            rollbar.error("SFRegisterLRT error:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * sfRegisterStudio
 * @param {object} event
 * @param {object} add_info
 * @param {number} sf_auth
 */
async function sfRegisterStudio(event, add_info, sf_auth) {
    try {

        var visitor = ua(config.Verifyunit.googleAnalyticsID);
        var duration = (event.type == "invoice.payment_succeeded") ?
            ((event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.interval == "year") ? 12 : (event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.interval == "month" ? 1 : 0)) :
            ((event.data.object.items.data[event.data.object.items.total_count - 1].plan.interval == "year") ? 12 : (event.data.object.items.data[event.data.object.items.total_count - 1].plan.interval == "month" ? 1 : 0));
        var url = (process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod') ? config.Verifyunit.DEV.URI + config.Verifyunit.endpoints.isvalidunit : config.Verifyunit.PROD.URI + config.Verifyunit.endpoints.isvalidunit;
        var r_key = "";
        var promocode = "";
        if (event.data.object.discount) {
            var coupon = event.data.object.discount.coupon.id;
            if (coupon.substring(0, 4) == "LRT_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 7) == "GRHADV_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 7) == "GRHBAS_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "SC2M_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "SC3M_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "solo-") {
                promocode = coupon;
            }
        }

        var options = {
            method: 'POST',
            uri: url,
            resolveWithFullResponse: true,
            headers: {
                'Authorization': "Bearer " + sf_auth
            },
            body: {
                "SerialNumber": "",
                "service_type": "Graphics",
                "TypeOfAction": "Customer Service",
                "unit_id": "",
                "part_number": (event.type == "invoice.payment_succeeded") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.metadata.part_number : event.data.object.items.data[event.data.object.items.total_count - 1].plan.metadata.part_number,
                "hours": (event.type == "invoice.payment_succeeded") ? ((event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.metadata.seconds) / 3600) : ((event.data.object.items.data[event.data.object.items.total_count - 1].plan.metadata.seconds) / 3600),
                "extraHours": 0,
                "email": add_info.email,
                "customerId": event.data.object.customer,
                "timestamp": Math.floor(Date.now() / 1000),
                "interval": duration,
                "amount": (event.data.object.amount_paid / 100),
                "currencyCode": event.data.object.currency ? event.data.object.currency.toUpperCase() : 'USD',
                "paid": event.data.object.paid,
                "address_city": add_info.metadata.city,
                "address_country": add_info.metadata.country,
                "address_line1": add_info.metadata.add_line1,
                "address_line2": add_info.metadata.add_line2,
                "address_state": add_info.metadata.state,
                "address_zip": add_info.metadata.zipcode,
                "DealNumber": (event.type == "invoice.payment_succeeded") ? event.data.object.number : event.id.split('_').pop(),
                "RegistrationKey": r_key,
                "PromotionalCodes": promocode,
                "SalesTax": (event.data.object.tax / 100),
                "LRTSerialNumber": ""
            },
            json: true
        };
        console.log(options.body);
        const data = await rp(options);
        let obj = JSON.parse(data.body);
        console.log(obj);
        if (obj.result != "success") {
            if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
                rollbarWarn = {
                    "description": (obj.result ? obj.result : 'No Studio message'),
                    "payload": (options.body),
                    "sfresponse": data,
                    "user": (add_info.email ? add_info.email : 'user not found')
                };
                rollbar.warning(
                    "sfRegisterStudio: " + "description: " + (obj.result ? obj.result : 'No Studio message') + " user:" + (add_info.email ? add_info.email : 'user not found'),
                    rollbarWarn);

            }
            var label = JSON.stringify(options.body);
            visitor.event("Salesforce Register endpoint-" + process.env.ENVIRONMENT, obj.result, label, 1).send();
        }
        return data.body;
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.status = err.status;
            rollbarErr.description = err.message;
            rollbar.error("SFRegisterStudio error:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * sfRegisterSoloConnect
 * @param {object} event
 * @param {object} add_info
 * @param {number} sf_auth
 */
async function sfRegisterSoloConnect(event, add_info, sf_auth) {
    try {

        var visitor = ua(config.Verifyunit.googleAnalyticsID);
        var duration = (event.type == "invoice.payment_succeeded") ?
            ((event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.interval == "year") ? 12 : (event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.interval == "month" ? 1 : 0)) :
            ((event.data.object.items.data[event.data.object.items.total_count - 1].plan.interval == "year") ? 12 : (event.data.object.items.data[event.data.object.items.total_count - 1].plan.interval == "month" ? 1 : 0));
        var url = (process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod') ? config.Verifyunit.DEV.URI + config.Verifyunit.endpoints.isvalidunit : config.Verifyunit.PROD.URI + config.Verifyunit.endpoints.isvalidunit;
        var r_key = "";
        var promocode = "";
        if (event.data.object.discount) {
            var coupon = event.data.object.discount.coupon.id;
            if (coupon.substring(0, 4) == "LRT_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 7) == "GRHADV_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 7) == "GRHBAS_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "SC2M_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "SC3M_") {
                r_key = coupon;
            }
            if (coupon.substring(0, 5) == "solo-") {
                promocode = coupon;
            }
        }

        var options = {
            method: 'POST',
            uri: url,
            resolveWithFullResponse: true,
            headers: {
                'Authorization': "Bearer " + sf_auth
            },
            body: {
                "SerialNumber": (event.type == "invoice.payment_succeeded") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unitsn : event.data.object.metadata.unitsn,
                "service_type": "LRT",
                "TypeOfAction": "Service",
                "unit_id": (event.type == "invoice.payment_succeeded") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unit_id : event.data.object.metadata.unit_id,
                "part_number": (event.type == "invoice.payment_succeeded") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].plan.metadata.part_number : event.data.object.items.data[event.data.object.items.total_count - 1].plan.metadata.part_number,
                "hours": 0,
                "extraHours": 0,
                "email": add_info.email,
                "customerId": event.data.object.customer,
                "timestamp": Math.floor(Date.now() / 1000),
                "interval": duration,
                "amount": (event.data.object.amount_paid / 100),
                "currencyCode": event.data.object.currency ? event.data.object.currency.toUpperCase() : 'USD',
                "paid": event.data.object.paid,
                "address_city": add_info.metadata.city,
                "address_country": add_info.metadata.country,
                "address_line1": add_info.metadata.add_line1,
                "address_line2": add_info.metadata.add_line2,
                "address_state": add_info.metadata.state,
                "address_zip": add_info.metadata.zipcode,
                "DealNumber": (event.type == "invoice.payment_succeeded") ? event.data.object.number : event.id.split('_').pop(),
                "RegistrationKey": r_key,
                "PromotionalCodes": promocode,
                "SalesTax": (event.data.object.tax / 100),
                "LRTSerialNumber": (event.type == "invoice.payment_succeeded") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.lrtsn : event.data.object.metadata.lrtsn
            },
            json: true
        };
        console.log(options.body);
        const data = await rp(options);
        let obj = JSON.parse(data.body);
        console.log(obj);
        if (obj.result != "success") {
            if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
                rollbarWarn = {
                    "description": (obj.result ? obj.result : 'No Connect message'),
                    "payload": (options.body),
                    "sfresponse": data,
                    "user": (add_info.email ? add_info.email : 'user not found'),
                    "unitId": (event.type == "invoice.payment_succeeded") ? (event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unit_id) : (event.data.object.items.data[event.data.object.items.total_count - 1].metadata.unit_id)
                };
                rollbar.warning(
                    "sfRegisterSoloConnect: description: " + (obj.result ? obj.result : 'No Connect message') + " user: " + (add_info.email ? add_info.email : 'user not found') + " unitId: " + (event.type == "invoice.payment_succeeded") ? (event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unit_id) : (event.data.object.items.data[event.data.object.items.total_count - 1].metadata.unit_id),
                    rollbarWarn);

            }
            var label = JSON.stringify(options.body);
            visitor.event("Salesforce Register endpoint-" + process.env.ENVIRONMENT, obj.result, label, 1).send();
            return data.body;
        }
        else {
            let sendemail = await emailservice(event, options.body, sf_auth);
            return sendemail;
        }
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.status = err.status;
            rollbarErr.description = err.message;
            rollbar.error("sfRegisterSoloConnect error:" + err.message, rollbarErr);
        }
        throw err;
    }
}

// function to edit email template and send email
async function emailservice(event, userinfo, sf_auth) {
    try {
        var s_id = (event.type == "invoice.payment_succeeded") ? event.data.object.lines.data[event.data.object.lines.total_count - 1].id : event.data.object.items.data[event.data.object.items.total_count - 1].subscription;
        //Check if email is already sent to user
        var params = {
            TableName: 'user_subscription_' + process.env.ENVIRONMENT,
            KeyConditionExpression: "#subscription_id = :subscription_id",
            FilterExpression: "#is_emailsent = :is_emailsent",
            ExpressionAttributeNames: {
                "#subscription_id": "subscription_id",
                "#is_emailsent": "is_emailsent"
            },
            ExpressionAttributeValues: {
                ":subscription_id": s_id,
                ":is_emailsent": false
            }
        };

        const isEmailSent = await docClient.query(params).promise();

        if (isEmailSent.Count) {
            let activate = await connectActivation(userinfo, sf_auth)
            let data = await fs_extra.copy(__dirname + "/index.html", '/tmp/index.html');
            let fileData = fs.readFileSync('/tmp/index.html', 'utf8');
            let replacesnnumber = `<h3><span style="font-size:16px; font-weight: 400;"> This is an automatic email confirming that an end user would like to activate a data plan for the following Solo Connect modem pack: </span></br><span style="font-size:16px;">` + userinfo.LRTSerialNumber + `</span></h3>`;
            var result = fileData.replace(/replacesnnumber/g, replacesnnumber);
            var emailparams = {
                Destination: {
                    ToAddresses: ['soloconnectactivations@liveu.tv']
                },
                Message: {
                    Body: {
                        Html: {
                            Charset: "UTF-8",
                            Data: result
                        }
                    },
                    Subject: {
                        Charset: 'UTF-8',
                        Data: 'Solo Connect Activation',
                    }
                },
                Source: "solo.help@liveu.tv"
            };

            let mailconfig = new AWS.SES({ apiVersion: '2010-12-01' });
            let mail = await mailconfig.sendEmail(emailparams).promise();
            if (mail) {
                //set email sent flag to true
                let params = {
                    TableName: 'user_subscription_' + process.env.ENVIRONMENT,
                    Key: {
                        "subscription_id": s_id
                    },
                    UpdateExpression: "set is_emailsent = :s",
                    ExpressionAttributeValues: {
                        ":s": true
                    },
                    ReturnValues: "UPDATED_NEW"
                };

                const data = await docClient.update(params).promise();
                console.log("Email sent and dynamo updated");
            }
            return 'Email sent and SF solo connect called successfully';
        } else {
            console.log("Email already sent");
            return 'Email already sent and Sf solo connect called successfully';
        }
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.status = err.status;
            rollbarErr.description = err.message;
            rollbar.error("Email error:" + err.message, rollbarErr);
        }
        throw err;
    }
}

/**
 * connectActivation
 * @param {object} event
 * @param {object} add_info
 * @param {number} sf_auth
 */
async function connectActivation (userinfo, sf_auth) {
    try {
        var visitor = ua(config.Verifyunit.googleAnalyticsID);
        var url = (process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod') ? config.Verifyunit.DEV.URI + config.Verifyunit.endpoints.isvalidunit : config.Verifyunit.PROD.URI + config.Verifyunit.endpoints.isvalidunit;

        var options = {
            method: 'POST',
            uri: url,
            resolveWithFullResponse: true,
            headers: {
                'Authorization': "Bearer " + sf_auth
            },
            body: {
                "SerialNumber": userinfo.SerialNumber,
                "service_type": "LRT",
                "TypeOfAction": "Service",
                "unit_id": userinfo.unit_id,
                "part_number": "LU-SOLO-LRTC-ACTIVATE",
                "hours": 0,
                "extraHours": 0,
                "email": userinfo.email,
                "customerId": userinfo.customerId,
                "timestamp": Math.floor(Date.now() / 1000),
                "interval": 0,
                "amount": 0,
                "currencyCode": userinfo.currencyCode,
                "paid": userinfo.paid,
                "address_city": userinfo.address_city,
                "address_country": userinfo.address_country,
                "address_line1": userinfo.address_line1,
                "address_line2": userinfo.address_line2,
                "address_state": userinfo.address_state,
                "address_zip": userinfo.address_zip,
                "DealNumber": userinfo.DealNumber,
                "RegistrationKey": "",
                "PromotionalCodes": "",
                "SalesTax": 0,
                "LRTSerialNumber": userinfo.LRTSerialNumber
            },
            json: true
        };
        console.log(options.body);
        const data = await rp(options);
        let obj = JSON.parse(data.body);
        console.log(obj);
        if (obj.result != "success") {
            if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
                rollbarWarn = {
                    "description": (obj.result ? obj.result : 'No Activation message'),
                    "payload": (options.body),
                    "sfresponse": data,
                    "user": (add_info.email ? add_info.email : 'user not found'),
                    "unitId": (event.type == "invoice.payment_succeeded") ? (event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unit_id) : (event.data.object.items.data[event.data.object.items.total_count - 1].metadata.unit_id)
                };
                rollbar.warning(
                    "connectActivation: description: " + (obj.result ? obj.result : 'No Activation message') + " user: " + (add_info.email ? add_info.email : 'user not found') + " unitId: " + (event.type == "invoice.payment_succeeded") ? (event.data.object.lines.data[event.data.object.lines.total_count - 1].metadata.unit_id) : (event.data.object.items.data[event.data.object.items.total_count - 1].metadata.unit_id),
                    rollbarWarn);

            }
            var label = JSON.stringify(options.body);
            visitor.event("Salesforce Register endpoint-" + process.env.ENVIRONMENT, obj.result, label, 1).send();
            return data.body;
        }
        return data.body;
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.status = err.status;
            rollbarErr.description = err.message;
            rollbar.error("SFCharge refunded error:" + err.message, rollbarErr);
        }
        throw err;
    }
}


/**
 * chargeRefunded
 * @param {object} event
 * @param {object} add_info
 * @param {number} sf_auth
 */
async function chargeRefunded(event, add_info, sf_auth, details) {
    try {
        var visitor = ua(config.Verifyunit.googleAnalyticsID);
        var url = (process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod') ? config.Verifyunit.DEV.URI + config.Verifyunit.endpoints.isvalidunit : config.Verifyunit.PROD.URI + config.Verifyunit.endpoints.isvalidunit;

        var options = {
            method: 'POST',
            uri: url,
            resolveWithFullResponse: true,
            headers: {
                'Authorization': "Bearer " + sf_auth
            },
            body: {
                "SerialNumber": "",
                "service_type": details.service_type,
                "TypeOfAction": details.type_of_action,
                "unit_id": details.unit_id,
                "part_number": details.part_number,
                "hours": details.hours,
                "extraHours": details.extra_hours,
                "email": add_info.email,
                "customerId": event.data.object.customer,
                "timestamp": Math.floor(Date.now() / 1000),
                "interval": details.interval,
                "amount": -(event.data.object.amount_refunded / 100),
                "currencyCode": event.data.object.currency ? event.data.object.currency.toUpperCase() : 'USD',
                "paid": event.data.object.paid,
                "address_city": add_info.metadata.city,
                "address_country": add_info.metadata.country,
                "address_line1": add_info.metadata.add_line1,
                "address_line2": add_info.metadata.add_line2,
                "address_state": add_info.metadata.state,
                "address_zip": add_info.metadata.zipcode,
                "DealNumber": event.id.split('_').pop(),
                "RegistrationKey": "",
                "PromotionalCodes": "",
                "SalesTax": parseFloat(details.taxamount).toFixed(2),
                "LRTSerialNumber": ""
            },
            json: true
        };
        console.log(options.body);
        const data = await rp(options);
        let obj = JSON.parse(data.body);
        console.log(obj);
        if (obj.result != "success") {
            if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
                rollbarWarn = {
                    "description": (obj.result ? obj.result : 'No inner message'),
                    "payload": options.body,
                    "sfresponse": data,
                    "unitId": (details.unit_id ? details.unit_id : "UnitId not found"),
                    "user": (add_info.email ? add_info.email : 'user not found')
                };
                rollbar.warning(
                    "chargeRefunded: description: " + (obj.result ? obj.result : 'No inner message') + " unitId: " + (details.unit_id ? details.unit_id : "UnitId not found") + " user: " + (add_info.email ? add_info.email : 'user not found'),
                    rollbarWarn);
            }
            var label = JSON.stringify(options.body);
            visitor.event("Salesforce Register endpoint-" + process.env.ENVIRONMENT, obj.result, label, 1).send();
        }
        return data.body;
    }
    catch (err) {
        console.log(err);
        if (process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod' || process.env.ENVIRONMENT == 'prod') {
            rollbarErr.status = err.status;
            rollbarErr.description = err.message;
            rollbar.error("SFCharge refunded error:" + err.message, rollbarErr);
        }
        throw err;
    }
}


/**
 * GetRandomGUID
 */
function GetRandomGUID() {
    var result;
    var i;
    var j;
    result = '';
    for (j = 0; j < 32; j++) {
        if (j == 8 || j == 12 || j == 16 || j == 20) {
            result = result + '-';
        }
        i = Math.floor(Math.random() * 16).toString(16).toUpperCase();
        result = result + i;
    }
    return result;
}