'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});
const stripe = require("stripe")(
    process.env.StripeKey
);
var _ = require('lodash');


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
    const invoices = await getInvoices(query);
    const allinvoices = invoices.has_more ? await getAllInvoices(query, invoices.data[invoices.data.length - 1].id, invoices) : invoices;
    console.log(allinvoices.data.length);
    const customers = allinvoices.data.length ? await getCustomerId() : null;
    console.log(customers.length)
    const studioinvoice = (allinvoices.data.length && customers.length) ? await getStudioInvoices(allinvoices, customers) : { "message": "No studio sales" };
    console.log(studioinvoice.length);
    responseBody.data = {
        response: studioinvoice,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getInvoices
 * @description get all charges of user
 * */
async function getInvoices(event) {
    try {
        const data = await stripe.invoices.list({
            limit: 100,
            date: {
                gte: event.s_date,
                lte: event.e_date
            }
        });
        return data;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name getCustomerId
 * @description get studio license of user
 * */
async function getCustomerId() {
    try {
        const params = {
            TableName: "stripe_users_" + process.env.ENVIRONMENT
        };
        const data = await docClient.scan(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}


/**
 * getInvoices
 */
async function getAllInvoices(event, id, invoices) {
    try {
        let result = [];
        await test(event, id, invoices.data);
        async function test(event, id, res) {
            try {
                const data = await stripe.invoices.list({
                    limit: 100,
                    starting_after: id,
                    date: {
                        gte: event.s_date,
                        lte: event.e_date
                    }
                });
                result = await _.concat(res, data.data);

                if (data.has_more) {
                    await test(event, data.data[data.data.length - 1].id, result);
                }
                else {
                    return result;

                }
            }
            catch (err) {
                throw err;
            }
        }
        invoices.data = result;
        return invoices;
    }
    catch (err) {
        throw err;
    }
}

/**
 * getStudioInvoices
 */
async function getStudioInvoices(event, user_data) {
    try {
        let result = [];
        await event.data.forEach(function(item, key) {
            if (item.lines.data[0].type != 'invoiceitem') {
                if (item.lines.data[0].plan.metadata.service_type == "studio") {
                    item.email = _.find(user_data, function(o) {
                        return o.customer_id === item.customer;
                    });
                    result.push(item);
                    if (key === event.data.length - 1) {
                        return result;
                    }
                }
                else if (key === event.data.length - 1) {
                    if (result.length) {
                        return result;
                    }
                    else {
                        return null;
                    }
                }
            }
        });
        return result;
    }
    catch (err) {
        throw err;
    }
}
