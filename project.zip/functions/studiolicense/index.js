//start subscription with default card for Studio Services
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const user = await checkIfLicenceExists(params.customer_id);
    console.log(user);
    const license = user ? { "message": "Licence already exists" } : await insertUserLicense(params);
    responseBody.data = {
        response: license,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };
});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name checkIfLicenceExists
 * @description get unit settings
 * */
async function checkIfLicenceExists(customer_id) {
    try {
        const params = {
            TableName: "user_licence_" + process.env.ENVIRONMENT,
            KeyConditionExpression: "#customer_id = :customer_id",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id
            }
        };
        const data = await docClient.query(params).promise();
        if (data.Count) {
            return data.Items;
        }
        else {
            return null;
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

/**
 * @name insertUserLicense
 * @description get unit settings
 * */
async function insertUserLicense(event) {
    try {
        const params = {
            Item: {
                licence_id: GetRandomGUID(),
                subscription_id: event.subscription_id,
                customer_id: event.customer_id,
                licence_type: event.package_type,
                starter_bucket_hours: event.starter_bucket_hours,
                extra_hours: 0,
                added_on: Math.floor(Date.now() / 1000),
                updated_on: Math.floor(Date.now() / 1000),
                is_active: true,
                interval: event.interval,
                last_crondate: Math.floor(Date.now() / 1000)
            },
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
        };
        const data = await docClient.put(params).promise();
        return data;
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}

function GetRandomGUID() {
    var result;
    var i;
    var j;
    result = '';
    for (j = 0; j < 32; j++) {
        if (j == 8 || j == 12 || j == 16 || j == 20) {
            result = result + '-';
        }
        i = Math.floor(Math.random() * 16).toString(16).toUpperCase();
        result = result + i;
    }
    return result;
}
