//Switchboard operations
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors, config} = require("solo-utils");
const eConfig = require('./config.json');
const axios = require('axios');

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);

    try {
        let funRes;
        switch (event.queryStringParameters.operation) {
            case 'create_stream':
                console.log(event.queryStringParameters.operation);
                funRes = await sbCreate(event, params);
                break;
            case 'update_stream':
                console.log(event.queryStringParameters.operation);
                funRes = await sbUpdateStream(event, params);
                break;
            case 'stream_details':
                console.log(event.queryStringParameters.operation);
                funRes = await sbGetStreamDetails(event);
                break;
            case 'delete_stream':
                console.log(event.queryStringParameters.operation);
                funRes = await sbDeleteStream(event);
                break;
            case 'profile':
                console.log(event.queryStringParameters.operation);
                funRes = await sbGetProfile(event);
                break;
            case 'user_id':
                console.log(event.queryStringParameters.operation);
                funRes = await sbUser(event);
                break;
            case 'all_streams':
                console.log(event.queryStringParameters.operation);
                funRes = await sbAllStreams(event);
                break;
            default:
                throw new errors.APIError(404, {
                    code: 404,
                    property: "switchboard",
                    message: JSON.stringify(eConfig.required)
                });
        }
        console.log(event.queryStringParameters.operation);
        if (!event.queryStringParameters.operation) {
            throw new errors.APIError(404, {
                code: 404,
                property: "switchboard",
                message: JSON.stringify(eConfig.required)
            });
        }

        responseBody.data = {
            response: funRes,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    } catch (err) {
        if (err.code) {
            if (err.code == 401) {
                err.code = 403;
            }
            err.statusCode = err.code;
            statusCode = err.code;
            err.requestId = context.awsRequestId;
            responseBody.errors = [err];
        } else {
            statusCode = err.statusCode;
            err.requestId = context.awsRequestId;
            responseBody.errors = [err];
        }

    }
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }));

module.exports = {handler};

/**
 * @name getToken
 * @description get Switchboard
 * */
async function sbCreate(event, body) {
    console.log("reached create_stream");
    console.log("body", body.stream_name)
    try {
        let options = {
            method: 'POST',
            url: eConfig.Switchboard.endpoints.basePath + event.queryStringParameters.customer_id + '/streams',
            headers: {
                'Authorization': event.headers.Authorization,
                'Content-Type': 'application/json'
            },
            data: {"Label": body.stream_name},
            json: true
        };
        console.log(options)
        let res = await axios(options);
        let stream_id = res.headers.location.slice(res.headers.location.lastIndexOf("/") + 1, res.headers.location.length);
        return {"stream_id": stream_id}
    } catch (err) {
        console.log("err", err)
        throw new errors.APIError(err.response.status, {
            code: err.response.status == 401 ? 403 : err.response.status,
            property: "switchboard",
            message: err.response.statusText,
        });
    }
}

async function sbUpdateStream(event, body) {
    try {
        let options = {
            method: 'PUT',
            url: eConfig.Switchboard.endpoints.basePath + event.queryStringParameters.customer_id + '/streams/ ' + event.queryStringParameters.stream_id,
            headers: {
                'Authorization': event.headers.Authorization,
                'Content-Type': 'application/json'
            },
            data: {
                "Label": body.stream_name
            },
            json: true
        };
        let res = await axios(options);
        return {"stream_updated": true}
    } catch (err) {
        console.log("err", err);
        throw new errors.APIError(err.response.status, {
            code: err.response.status == 401 ? 403 : err.response.status,
            property: "switchboard",
            message: err.response.statusText,
        });
    }
}

async function sbGetStreamDetails(event) {
    try {
        let options = {
            method: 'GET',
            url: eConfig.Switchboard.endpoints.basePath + event.queryStringParameters.customer_id + '/streams/' + event.queryStringParameters.stream_id + '/stream-key',
            headers: {
                'Authorization': event.headers.Authorization,
                'Content-Type': 'application/json'
            },
            json: true
        };
        let res = await axios(options);
        return res.data;
    } catch (err) {
        console.log("err", err);
        throw new errors.APIError(err.response.status, {
            code: err.response.status == 401 ? 403 : err.response.status,
            property: "switchboard",
            message: err.response.statusText,
        });
    }
}

async function sbDeleteStream(event) {
    try {
        let options = {
            method: 'DELETE',
            url: eConfig.Switchboard.endpoints.basePath + event.queryStringParameters.customer_id + '/streams/' + event.queryStringParameters.stream_id,
            headers: {
                'Authorization': event.headers.Authorization
            },
            json: true
        };
        let res = await axios(options);
        return {"stream_deleted": true};
    } catch (err) {
        console.log("err", err);
        throw new errors.APIError(err.response.status, {
            code: err.response.status == 401 ? 403 : err.response.status,
            property: "switchboard",
            message: err.response.statusText,
        });
    }
}

async function sbGetProfile(event) {
    try {
        let options = {
            method: 'GET',
            url: eConfig.Switchboard.endpoints.basePath + event.queryStringParameters.customer_id,
            headers: {
                'Authorization': event.headers.Authorization,
                'Accept': 'application/json'
            },
            json: true
        };
        let res = await axios(options);
        return res.data;
    } catch (err) {
        console.log("err", err);
        throw new errors.APIError(err.response.status, {
            code: err.response.status == 401 ? 403 : err.response.status,
            property: "switchboard",
            message: err.response.statusText,
        });
    }
}

async function sbUser(event) {
    console.log("reached user_id")
    try {
        let options = {
            method: 'GET',
            url: 'https://cloud.switchboard.live/1.0/customers',
            headers: {
                'Authorization': event.headers.Authorization,
                'Accept': 'application/json'
            },
            json: true
        };
        console.log(options);
        let res = await axios(options);
        return res.data;
    } catch (err) {
        console.log("err", err);
        throw new errors.APIError(err.response.status, {
            code: err.response.status == 401 ? 403 : err.response.status,
            property: "switchboard",
            message: err.response.statusText,
        });
    }
}

async function sbAllStreams(event) {
    console.log("reached all_streams")
    try {
        let options = {
            method: 'GET',
            url: 'https://cloud.switchboard.live/1.0/customers/' + event.queryStringParameters.customer_id + '/streams',
            headers: {
                'Authorization': event.headers.Authorization,
                'Accept': 'application/json'
            },
            json: true
        };
        console.log(options);
        let res = await axios(options);
        if (!res.data.length) {
            return {"no_streams": true}
        } else {
            return res.data;
        }

    } catch (err) {
        console.log("err", err);
        throw new errors.APIError(err.response.status, {
            code: err.response.status == 401 ? 403 : err.response.status,
            property: "switchboard",
            message: err.response.statusText,
        });
    }
}