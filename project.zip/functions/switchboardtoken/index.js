//Switchboard token
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors} = require("solo-utils");
const config = require('./config.json');
const rp = require('request-promise');
let clientId;


/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);

    try {
        console.log(params);
        const token = await getToken(params);
        responseBody.data = {
            response: token,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    } catch (err) {
        if (err.statusCode == 401)
            err.statusCode = 403;
        statusCode = err.statusCode;
        err.requestId = context.awsRequestId;
        responseBody.errors = [err];
    }
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = {handler};

/**
 * @name getToken
 * @description get Switchboard token
 * */
async function getToken(event) {
    try {
        switch (event.appMode) {
            case 'DEV':
                clientId = config.Switchboard.credentials.DEV.clientId;
                break;

            case 'QA':
                clientId = config.Switchboard.credentials.QA.clientId;
                break;

            case 'PROD':
                clientId = config.Switchboard.credentials.PROD.clientId;
                break;
            case 'SEMIPROD':
                clientId = config.Switchboard.credentials.SEMIPROD.clientId;
                break;

            default:
                clientId = config.Switchboard.credentials.DEV.clientId;
                break;
        }
        var options = {
            method: 'POST',
            uri: config.Switchboard.URI + config.Switchboard.endpoints.token,
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            resolveWithFullResponse: true,
            form: {
                client_id: clientId,
                grant_type: event.grant_type,
                code: event.code,
                redirect_uri: event.redirect_uri
            },
            json: true
        };
        let result = await rp(options);
        return result.body;
    } catch (err) {
        throw new errors.APIError(err.statusCode, {
            code: null,
            property: "switchboard",
            message: err.error.error_description,
        });
    }
}