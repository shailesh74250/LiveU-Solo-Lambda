"use strict";
const Memcached = require('memcached');
const memcached = new Memcached(process.env.ConfigEndpoint);
const { errors } = require("solo-utils");
const HttpStatus = require('http-status-codes');

exports.handler = async(event, context) => {
	let responseBody = {};
	try {
		const data = await tokenVerification(event);
		responseBody.data = data;
	}
	catch (err) {
        responseBody.errors = [err];
	}

	return responseBody;
};

function tokenVerification(event) {
	//console.log(event)
	return new Promise((resolve, reject) => {
		memcached.get(event.username, function (err, data) {
			if (err) {
				reject(new errors.APIError(HttpStatus.UNAUTHORIZED, {
					code: null,
					message: HttpStatus.getStatusText(HttpStatus.UNAUTHORIZED),
				}));
			} else {
				if (event.token && data == event.token.split(" ").pop()) {
					memcached.touch(event.username, 14400, function (err) {
						if (err) {
							reject(new errors.APIError(HttpStatus.UNAUTHORIZED, {
								code: null,
								message: HttpStatus.getStatusText(HttpStatus.UNAUTHORIZED),
							}));
						} else {
							resolve({
								"status": HttpStatus.OK
							});
						}
					});
				} else {
					reject(new errors.APIError(HttpStatus.UNAUTHORIZED, {
						code: null,
						message: HttpStatus.getStatusText(HttpStatus.UNAUTHORIZED),
					}));
				}
			}
		});
	});
}
