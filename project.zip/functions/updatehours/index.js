//Update user studio hours after streaming
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const customer = await getCustomerLicense(params.customer_id);
    const license = await updateUserLicense(params, customer);
    responseBody.data = {
        response: license,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name getCustomerLicense
 * @description get user stripe customer id 
 * */
async function getCustomerLicense(customer_id) {
    try {
        const params = {
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
            KeyConditionExpression: "#customer_id = :customer_id",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id"
            },
            ExpressionAttributeValues: {
                ":customer_id": customer_id
            }
        };
        const data = await docClient.query(params).promise();
        return data.Items[0];
    }
    catch (err) {

        throw err;
    }
}

/**
 * @name updateUserLicense
 * @description get destination details
 * */
async function updateUserLicense(event, customer) {
    try {
        var params = {};
        if (parseInt(customer.starter_bucket_hours) > parseInt(event.time)) {
            params = {
                TableName: 'user_licence_' + process.env.ENVIRONMENT,
                Key: {
                    "customer_id": event.customer_id
                },
                UpdateExpression: "set starter_bucket_hours = :h",
                ExpressionAttributeValues: {
                    ":h": parseInt(customer.starter_bucket_hours) - parseInt(event.time)
                },
                ReturnValues: "ALL_NEW"
            };
        }
        else if ((parseInt(customer.starter_bucket_hours) + parseInt(customer.extra_hours)) < parseInt(event.time)) {

            params = {
                TableName: 'user_licence_' + process.env.ENVIRONMENT,
                Key: {
                    "customer_id": event.customer_id
                },
                UpdateExpression: "set starter_bucket_hours = :h , extra_hours = :t",
                ExpressionAttributeValues: {
                    ":h": 0,
                    ":t": 0
                },
                ReturnValues: "ALL_NEW"
            };
        }
        else {
            var starter_hours = 0;
            var remaining_hour = parseInt(event.time) - parseInt(customer.starter_bucket_hours);
            params = {
                TableName: 'user_licence_' + process.env.ENVIRONMENT,
                Key: {
                    "customer_id": event.customer_id
                },
                UpdateExpression: "set starter_bucket_hours = :h , extra_hours = :t",
                ExpressionAttributeValues: {
                    ":h": starter_hours,
                    ":t": parseInt(customer.extra_hours) - remaining_hour
                },
                ReturnValues: "ALL_NEW"
            };
        }
        console.log(params)
        const data = await docClient.update(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}
