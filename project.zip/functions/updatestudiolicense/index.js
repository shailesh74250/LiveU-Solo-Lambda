//Update studio license of user
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    const license = await getUserLicense(params.customer_id);
    const updatedlicense = await updateUserLicense(params, license);
    responseBody.data = {
        response: updatedlicense,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;

    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };


/**
 * @name getUserLicense
 * * @description get user license
 * */
async function getUserLicense(user) {
    try {
        const params = {
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
            KeyConditionExpression: "#customer_id = :customer_id",
            ExpressionAttributeNames: {
                "#customer_id": "customer_id"
            },
            ExpressionAttributeValues: {
                ":customer_id": user
            }
        };
        const data = await docClient.query(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}

/**
 * @name updateUserLicense
 * * @description update user license
 * */
async function updateUserLicense(event, license) {
    try {
        const params = {
            TableName: 'user_licence_' + process.env.ENVIRONMENT,
            Key: {
                "customer_id": event.customer_id
            },
            ExpressionAttributeNames: {
                "#interval": "interval"
            },
            UpdateExpression: "set starter_bucket_hours = :h, extra_hours = :c, licence_type = :l , updated_on = :u, subscription_id = :s , #interval = :i",
            ExpressionAttributeValues: {
                ":h": parseInt(event.newtime),
                ":c": 0,
                ":l": event.license_type,
                ":u": Math.floor(Date.now() / 1000).toString(),
                ":s": event.subscription_id,
                ":i": event.interval
            },
            ReturnValues: "ALL_NEW"
        };
        const data = await docClient.update(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}
