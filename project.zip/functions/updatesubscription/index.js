'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
	process.env.StripeKey
);
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
	let responseBody = {};
	let statusCode;
	const params = JSON.parse(event.body);
	//const params = event.body;
	const subDetails = await getSubscription(params);
	const subscription = subDetails ? await updateSubscription(params, subDetails) : null ;
	const updatesubscription = (subscription && subDetails) ? await updateSubscriptionDetails(params, subscription) : null;
	responseBody.data = {
		response: updatesubscription,
		requestId: context.awsRequestId
	};
	statusCode = HttpStatus.OK;
	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = { handler };

/**
 * @name getSubscription
 * @description get subscription
 * */
async function getSubscription(event) {
	try {
		const data = await stripe.subscriptions.retrieve(event.subscription_id);
		return data;
	}
	catch (err) {
		throw err;
	}
}

/**
 * @name updateSubscription
 * @description updgrade/downgrade subscription 
 * */
async function updateSubscription(event, sub_res) {
	try {
		const data = await stripe.subscriptions.update(
			event.subscription_id,{
			items: [{
				id: sub_res.items.data[0].id,
				plan: event.plan
			}],
			coupon : event.coupon
			});
		return data;
	}
	catch (err) {
		throw err;
	}
}

/**
 * @name updateSubscriptionDetails
 * @description update destination details
 * */
async function updateSubscriptionDetails(event, sub_res) {
    try {
        const params = (event.type === "lrt") ? {
                TableName: 'user_subscription_' + process.env.ENVIRONMENT,
                Key: {
                    "subscription_id": event.subscription_id
                },
                ExpressionAttributeNames: {
                    "#interval": "interval"
                },
                UpdateExpression: "set plan_id = :p , #interval = :i ",
                ExpressionAttributeValues: {
                    ":p": event.plan,
                    ":i": event.interval
                },
                ReturnValues: "ALL_NEW"
            } : ( event.type === "studio" ? {
                TableName: 'user_subscription_' + process.env.ENVIRONMENT,
                Key: {
                    "subscription_id": event.subscription_id
                },
                ExpressionAttributeNames: {
                    "#interval": "interval"
                },
                UpdateExpression: "set plan_id = :p , #interval = :i , package_type = :t ",
                ExpressionAttributeValues: {
                    ":p": event.plan,
                    ":i": event.interval,
                    ":t": event.package_type
                },
                ReturnValues: "ALL_NEW"
            }  : {
                TableName: 'user_subscription_' + process.env.ENVIRONMENT,
                Key: {
                    "subscription_id": event.subscription_id
                },
                ExpressionAttributeNames: {
                    "#interval": "interval"
                },
                UpdateExpression: "set plan_id = :p , #interval = :i",
                ExpressionAttributeValues: {
                    ":p": event.plan,
                    ":i": event.interval
                },
                ReturnValues: "ALL_NEW"
            });
  
        const data = await docClient.update(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}