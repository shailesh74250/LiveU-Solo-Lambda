//Update user's lrt/studio subscription details
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({
    region: 'us-east-1'
});


/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
   const params = JSON.parse(event.body);
   // const params  = event.body;
    const subscription = await updateSubscription(params);
    responseBody.data = {
        response: subscription,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name updateSubscription
 * @description get destination details
 * */
async function updateSubscription(event) {
    try {
        const params = (event.type === "lrt") ? {
                TableName: 'user_subscription_' + process.env.ENVIRONMENT,
                Key: {
                    "subscription_id": event.subscription_id
                },
                ExpressionAttributeNames: {
                    "#interval": "interval"
                },
                UpdateExpression: "set plan_id = :p , #interval = :i ",
                ExpressionAttributeValues: {
                    ":p": event.plan_id,
                    ":i": event.interval
                },
                ReturnValues: "ALL_NEW"
            } : {
                TableName: 'user_subscription_' + process.env.ENVIRONMENT,
                Key: {
                    "subscription_id": event.subscription_id
                },
                ExpressionAttributeNames: {
                    "#interval": "interval"
                },
                UpdateExpression: "set plan_id = :p , #interval = :i , package_type = :t ",
                ExpressionAttributeValues: {
                    ":p": event.plan_id,
                    ":i": event.interval,
                    ":t": event.package_type
                },
                ReturnValues: "ALL_NEW"
            };
  
        const data = await docClient.update(params).promise();
        return data.Items;
    }
    catch (err) {
        throw err;
    }
}