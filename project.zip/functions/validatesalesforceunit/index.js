//SF validate solo connect unit
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const config = require('config.json');
const rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;

    const object = await validateUnit(event);
		responseBody.data = {
			response: object,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	})).
    use(errorFormatter());

module.exports = {handler};
/**
 * @name validateUnit
 * @description validate salesforce unit
 * */
async function validateUnit(event) {
	try {
        var body = JSON.parse(event.body);
        //var body = event.body;
        var options = {};
        if(process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod'){
            options = {
                method: 'POST',
                uri: config.Salesforce.credentials.DEV.URI + config.Salesforce.endpoints.validateunit,
                resolveWithFullResponse: true,
                headers: {
                    'Authorization': event.headers.Authorization
                },
                body: {
                    "SerialNumber": body.number
                },
                json: true
            };
        }
        else {
            options = {
                method: 'POST',
                uri: config.Salesforce.credentials.PROD.URI + config.Salesforce.endpoints.validateunit,
                resolveWithFullResponse: true,
                headers: {
                    'Authorization': event.headers.Authorization
                }, 
                body: {
                    "SerialNumber": body.number
                },
                json: true
            };
        }
		let result = await rp(options);
		return JSON.parse(result.body);
	} catch (err) {
	    console.log(err.error)
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"salesforce",
            message:err.error,
        });
	}
}