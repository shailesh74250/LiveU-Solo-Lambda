//Verify card by creating, capturing and refunding charge on card
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const params = JSON.parse(event.body);
    //const params = event.body;
    const token = await createToken(params);
    const charge = await createCharge(token.id);
    const capture = await chargeCapture(charge.id);
    const refund = await createRefund(charge.id);
    const cardToken = await createToken(params);
    responseBody.data = {
        response: cardToken,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name createToken
 * @description create stripe token
 * */
async function createToken(event) {
    try {
        const data = await stripe.tokens.create({
            card: {
                "name": event.name,
                "number": event.number,
                "exp_month": event.month,
                "exp_year": event.year,
                "cvc": event.cvc,
                "address_city": event.address_city,
                "address_country": event.address_country,
                "address_line1": event.address_line1,
                "address_line2": event.address_line2,
                "address_zip": event.address_zip,
                "address_state": event.address_state
            }
        });
        return data;
    }
    catch (err) {
        throw err;
    }
}


async function createCharge(token_id) {
    try {
        const data = stripe.charges.create({
            amount: 100,
            currency: "usd",
            description: "Verification Charge",
            capture: false,
            source: token_id,
        });
        return data;
    }
    catch (err) {
        throw err;
    }
}

async function chargeCapture(charge_id) {
    try {
        const data = stripe.charges.capture(charge_id);
        return data;
    }
    catch (err) {
        throw err;
    }
}

async function createRefund(charge_id) {
    try {
        const data = stripe.refunds.create({
            charge: charge_id
        });
        return data;
    }
    catch (err) {
        throw err;
    }
}
