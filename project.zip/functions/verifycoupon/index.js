//verify Coupon
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const { httpSecurityHeaders, cors } = require('middy/middlewares');
const { auth, errors, config } = require("solo-utils");
const AWS = require('aws-sdk');
const stripe = require("stripe")(
    process.env.StripeKey
);


/**handler function with middleware for authenticate*/
const handler = middy(async(event, context) => {
    let responseBody = {};
    let statusCode;
    const query = event.queryStringParameters;
    const coupon = await verifyCoupon(query);
    responseBody.data = {
        response: coupon,
        requestId: context.awsRequestId
    };
    statusCode = HttpStatus.OK;
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }))
    .use(auth());

module.exports = { handler };

/**
 * @name verifyCoupon
 * @description verify coupon
 * */
async function verifyCoupon(event) {
    try {
        const data = await stripe.coupons.retrieve(event.coupon);
        return data;
    }
    catch (err) {
        throw err;
    }
}