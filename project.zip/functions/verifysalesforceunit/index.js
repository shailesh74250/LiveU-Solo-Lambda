//Verify SF units
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {errorFormatter,errors} = require("solo-utils");
const config = require('config.json');
const rp = require('request-promise');

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;

    const object = await verifyUnit(event);
		responseBody.data = {
			response: JSON.parse(object),
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	})).
    use(errorFormatter());

module.exports = {handler};
/**
 * @name verifyUnit
 * @description verify salesforce unit
 * */
async function verifyUnit(event) {
	try {
        var body = JSON.parse(event.body);
        //var body = event.body;
        var options = {};
        if(process.env.ENVIRONMENT == 'dev' || process.env.ENVIRONMENT == 'qa' || process.env.ENVIRONMENT == 'semiprod'){
            options = {
                method: 'POST',
                uri: config.Salesforce.credentials.DEV.URI + config.Salesforce.endpoints.isvalidunit,
                resolveWithFullResponse: true,
                headers: {
                    'Authorization': event.headers.Authorization
                },
                body: {
                    "SerialNumber": body.number,
                    "Service":body.service
                },
                json: true
            };
        }
        else {
            options = {
                method: 'POST',
                uri: config.Salesforce.credentials.PROD.URI + config.Salesforce.endpoints.isvalidunit,
                resolveWithFullResponse: true,
                headers: {
                    'Authorization': event.headers.Authorization
                }, 
                body: {
                    "SerialNumber": body.number,
                    "Service":body.service
                },
                json: true
            };
        }
		let result = await rp(options);
		return result.body;
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: null,
            property:"salesforce",
            message:err.error[0].message,
        });
	}
}