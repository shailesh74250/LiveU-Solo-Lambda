//Vimeo token
'use strict';

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors} = require("solo-utils");
const config = require('./config.json');
const rp = require('request-promise');
var clientId;
var clientSecret;

/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
	let responseBody = {};
	let statusCode;
	const params = JSON.parse(event.body);

		const token = await getToken(params);
		responseBody.data = {
			response: token,
			requestId: context.awsRequestId
		};
		statusCode = HttpStatus.OK;

	return {
		statusCode: statusCode,
		body: JSON.stringify(responseBody),
		isBase64Encoded: false
	};

});

handler
	.use(httpSecurityHeaders())
	.use(cors({
		origins: ['*']
	}))
	.use(auth());

module.exports = {handler};

/**
 * @name getToken
 * @description get Vimeo token
 * */
async function getToken(event) {
	try {
		switch (process.env.ENVIRONMENT.toUpperCase()) {
			case 'LOCAL':
				clientId = config.Vimeo.credentials.LOCAL.clientId;
				clientSecret = config.Vimeo.credentials.LOCAL.clientSecret;
				break;

			case 'DEV':
				clientId = config.Vimeo.credentials.DEV.clientId;
				clientSecret = config.Vimeo.credentials.DEV.clientSecret;
				break;

			case 'QA':
				clientId = config.Vimeo.credentials.QA.clientId;
				clientSecret = config.Vimeo.credentials.QA.clientSecret;
				break;

			case 'PROD':
				clientId = config.Vimeo.credentials.PROD.clientId;
				clientSecret = config.Vimeo.credentials.PROD.clientSecret;
				break;

			case 'TEST':
				clientId = config.Vimeo.credentials.TEST.clientId;
				clientSecret = config.Vimeo.credentials.TEST.clientSecret;
				break;
			case 'SEMIPROD':
				clientId = config.Vimeo.credentials.SEMIPROD.clientId;
				clientSecret = config.Vimeo.credentials.SEMIPROD.clientSecret;
				break;
				
			default:
				clientId = config.Vimeo.credentials.LOCAL.clientId;
				clientSecret = config.Vimeo.credentials.LOCAL.clientSecret;
				break;
		}
		var options = {
			method: 'POST',
			uri: config.Vimeo.URI + config.Vimeo.endpoints.token,
			headers: {
			Authorization: 'Basic '+Buffer.from(clientId+':'+clientSecret).toString('base64')
			},
			resolveWithFullResponse: true,
			form: {
				code: event.code,
				redirect_uri: event.redirect_uri,
				grant_type: event.grant_type
			},
			json: true
		};
		let result = await rp(options);
		return result.body;
	} catch (err) {
		throw new errors.APIError(err.statusCode, {
            code: err.error.error_code,
            property:"vimeo",
            message:err.error.developer_message,
        });
	}
}