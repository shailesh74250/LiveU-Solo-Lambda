//Authenticate Zendesk API requests
'use strict';
const AWS = require('aws-sdk');
const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors, config} = require("solo-utils");
const eConfig = require('config.json');
const jwtsimple = require('jwt-simple');
const uuid = require('uuid');
const jwt = require('jsonwebtoken');
let jwtVerify;
/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    try {
        let body = JSON.parse(event.body);
        const jwtRes = await jwtVeri(event, body);
        const jwtEncode = jwtRes ? await jwtEnco(event, jwtRes, body) : {error: "JWT token error"};
        responseBody.data = {
            response: jwtEncode,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    } catch (err) {
        statusCode = err.statusCode;
        err.requestId = context.awsRequestId;
        responseBody.errors = [err];
    }
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }));

module.exports = {handler};

//Function to Verify JWT token
async function jwtVeri(event, body) {
    var isAuthorized = true;
    var scheme;
    var credentials;
    if (!event.headers.Authorization) {
        isAuthorized = false;
    }

    var parts = event.headers.Authorization.split(' ');
    if (parts.length !== 2) {
        isAuthorized = false;
    } else {
        scheme = parts[0];
        credentials = parts[1];
    }
    if (!/^Bearer$/i.test(scheme)) {
        isAuthorized = false;
    }
    if (isAuthorized && credentials) {
        var token = credentials;
        try {
            jwtVerify = await jwt.verify(token, eConfig.Zendesk.ZendeskSecretKey);
            if (jwtVerify.name !== body.email) {
                throw new errors.APIError(HttpStatus.INTERNAL_SERVER_ERROR, {
                    code: 401,
                    message: "Unauthorized Access Error",
                });
            }
            return jwtVerify;

        } catch (err) {
            throw new errors.APIError(HttpStatus.INTERNAL_SERVER_ERROR, {
                code: 401,
                message: err.message,
            });
        }
    }
}


//function to encode using jwtsimple
async function jwtEnco(event, jwtRes, body) {
    // jwtsimple encode
    try {
        var payload = {
            email: body.email,
            name: body.email,
            iat: (new Date().getTime() / 1000),
            jti: uuid.v4()
        };
        let jwtToken = await jwtsimple.encode(payload, eConfig.Zendesk.SharedKey);
        var redirect = 'https://' + eConfig.Zendesk.SubDomain + '.zendesk.com/access/jwt?jwt=' + jwtToken + '&return_to=' + body.return_to;
        jwtRes.redirect_url = redirect;
        return jwtRes;
    } catch (err) {
        throw new errors.APIError(HttpStatus.INTERNAL_SERVER_ERROR, {
            code: null,
            message: err.message,
        });
    }

}