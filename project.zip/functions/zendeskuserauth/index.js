//Zendesk user authorization
'use strict';
const AWS = require('aws-sdk');
const lambda = new AWS.Lambda({
    region: 'us-east-1'
});

const HttpStatus = require('http-status-codes');
const middy = require('middy');
const {httpSecurityHeaders, cors} = require('middy/middlewares');
const {auth, errors, config} = require("solo-utils");
const eConfig = require('config.json');
const rp = require('request-promise');
const jwtsimple = require('jwt-simple');
const uuid = require('uuid');
const btoa = require('btoa');
const jwt = require('jsonwebtoken');
let username;
let password;
let jwtPayload;
let sso_token;
/**handler function with middleware for authenticate*/
const handler = middy(async (event, context) => {
    let responseBody = {};
    let statusCode;
    try {
        let body = JSON.parse(event.body)
        const zenRes = await verifyZendesk(event);
        const jwtRes = zenRes ? await jwtToken() : {error: "ZenDesk error"};
        const storeRes = jwtRes ? await storeToken(event, zenRes) : {error: "JWT Token error"};
        const jwtsimRes = storeRes ? await jwtEncode(event, zenRes, body) : {error: "store token error"};
        responseBody.data = {
            response: jwtsimRes,
            requestId: context.awsRequestId
        };
        statusCode = HttpStatus.OK;
    } catch (err) {
        statusCode = err.statusCode;
        err.requestId = context.awsRequestId;
        responseBody.errors = [err];
    }
    return {
        statusCode: statusCode,
        body: JSON.stringify(responseBody),
        isBase64Encoded: false
    };

});

handler
    .use(httpSecurityHeaders())
    .use(cors({
        origins: ['*']
    }));

module.exports = {handler};

//function to invoke store token
async function storeToken(event, body) {
    try {
        const invoke = lambda.invoke({
            FunctionName: 'storetoken',
            Qualifier: process.env.ENVIRONMENT,
            InvocationType: 'RequestResponse',
            Payload: '{"username": "' + event.headers["x-user-name"] + '","token": "' + body.access_token + '"}'
        }).promise();
        return invoke;
    } catch (err) {
        throw err;
    }

}

//function to get Zendesk grant/authorization
async function verifyZendesk(event) {
    var isAuthorized = true;
    if (!event.headers.Authorization) {
        isAuthorized = false;
    }

    var parts = event.headers.Authorization.split(' ');
    if (parts.length < 2) {
        isAuthorized = false;
    }

    var scheme = parts[0],
        credentials = new Buffer(parts[1], 'base64').toString().split(':');

    if (!/Basic/i.test(scheme)) {
        isAuthorized = false;
    }
    if (credentials.length < 2) {
        isAuthorized = false;
    }
    username = credentials[0];
    password = credentials[1];
    if (!username || !password) {
        isAuthorized = false;
    }
    if (isAuthorized) {
        try {
            let options = {
                method: 'POST',
                uri: eConfig.Zendesk.ServerURL + eConfig.Zendesk.AuthDomain + 'j_oauth_token_grant',
                resolveWithFullResponse: true,
                headers: {
                    'Authorization': 'Basic ' + btoa(username + ':' + password)
                },
                json: true
            };
            let result = await rp(options);
            return result.body;
        } catch (err) {
            throw err;
        }
    } else {
        throw new errors.APIError(HttpStatus.INTERNAL_SERVER_ERROR, {
            code: 401,
            message: "Unauthorized Access Error",
        });
    }
}

//function to encode using jwtsimple
async function jwtEncode(event, zenRes, body) {
    // jwtsimple encode
    try {
        var token = await jwtsimple.encode(jwtPayload, eConfig.Zendesk.SharedKey);
        var redirect = 'https://' + eConfig.Zendesk.SubDomain + '.zendesk.com/access/jwt?jwt=' + token + '&return_to=' + body.return_to;
        zenRes.sso_token = sso_token;
        zenRes.redirect_url = redirect;
        return zenRes;
    } catch (err) {
        throw new errors.APIError(HttpStatus.INTERNAL_SERVER_ERROR, {
            code: null,
            message: err.message,
        });
    }

}

//function to generate token using jwt
async function jwtToken() {
    //SSO_token generation with JWT
    try {
        sso_token = await jwt.sign({name: username}, eConfig.Zendesk.ZendeskSecretKey, {expiresIn: '7d'});
        jwtPayload = {
            email: username,
            name: username,
            iat: (new Date().getTime() / 1000),
            jti: uuid.v4()
        };
        return sso_token;
    } catch (err) {
        throw new errors.APIError(HttpStatus.INTERNAL_SERVER_ERROR, {
            code: 401,
            message: err.message,
        });
    }

}